<!-- Hide from older browsers

    // Original JavaScript code by Duncan Crombie: dcrombie\@chirp.com.au
	// Using older version of Javascript for multiple browser support

    var today = new Date();

    function getCookie(name) { // use: getCookie(name);
	   var segments = document.cookie.split("; ") // break cookie into array of segments
       for (var i=0; i < segments.length; i++) {
          nextsegment = segments[i].split("=") // break into name and value
          if (nextsegment[0] == name) { // if name matches
            return unescape(nextsegment[1]) // return value
		  }
       }
       return null
    }

    var today = new Date();
    var expiry = new Date(today.getTime() + 60 * 24 * 60 * 60 * 1000); // plus 60 days
    
	function setCookie(name, value) { // use: setCookie(name, value)
       if (value != null && value != "")
	   {
          document.cookie=name + "=" + escape(value) + "; expires=" + expiry.toGMTString() + "; path=/"
		  return true
	   }
	   return false
    }

	function deleteCookie (name) {
	  var expired = new Date(today.getTime() - 4 * 60 * 60 * 1000); // minus 24 hours

	  if (getCookie(name)) {
		document.cookie = name + "=null; expires=" + expired.toGMTString() + "; path=/";
	  }
	}

	function makeCookie(name, value) { // make sure the cookie is set
	   if (getCookie(name)) {
		  deleteCookie (name)
	   }

	   if(!setCookie(name, value)) {
		  if (!confirm('The cookie was not accepted by your browser. You must allow cookies to use this page')) {
			alert('By refusing our harmless cookie strings you are preventing this page from operating correctly. Come back when you are ready to cooperate accept our cookies')
			history.back() // take them out of the page
		  }
	   }
	}

	function SetLoginInfo(theForm)
	{
		var nameVal = "ID"
		var id = getCookie(nameVal)
		if(id)
		{
			theForm.ID.value = id
		}
		
		theForm.submit()
		return true
	}

// -- End code 
// -->