function viewWindowPopup(link) {
		windowPopup(link, 500, 650);
}

function editWindowPopup(link) {
		windowPopup(link, 500,650);
}

function editPartWindowPopup(link) {
		windowPopup(link, 500,650);
}

function createWindowPopup(link) {     
		windowPopup(link, 500,650);
}

function queryWindowPopup(link) {
        windowPopup(link, 500,650);
}

function navigateWindowPopup(link) {
        windowPopup(link, 900,650);		
}

function addRemUsrWindowPopup(link) {
        windowPopup(link, 600,500);
}

function uploadWindowPopup(link) {
        windowPopup(link, 450,350);
}

function uploadFrmExtSysWindowPopup(link) {
        windowPopup(link, 400,250);
}

function updateFrmExtSysWindowPopup(link) {
        windowPopup(link, 400,250);
}

function chartWindowPopup(link) {
        windowPopup(link, 750,550);
}

function reportsWindowPopup(link) {
        windowPopup(link, 700,550);
}

function releaseWindowPopup(link) {
        windowPopup(link, 500,350);
}

function bomeditWindowPopup(link) {
        windowPopup(link, 800,400);
}

function partdataWindowPopup(link) {
        windowPopup(link, 800,350);
}

function permissionsWindowPopup(link) {
        windowPopup(link, 900,500);
}

function bomWindowPopup(link) {
        windowPopup(link, 800,600);
}

function qryselWindowPopup(link) {
        windowPopup(link, 600,600);
}

function toolLaunchWindowPopup(link) {
        windowPopup(link, 200,100);
}

function listWindowPopup(link) {
		windowPopup(link, 700,450);
}

function addItemWindowPopup(link) {
		windowPopup(link, 300,150);		
}

function partsWindowPopup(link) {
        windowPopup(link, 700,650);
}
function searchWindowPopup(link) {
        windowPopup(link, 400,400);
}

function addEditFilesWindowPopup(link) {
        windowPopup(link, 760,450);
}

function processWindowPopup(link) {
		windowPopup(link, 1000,570);
}

function messageWindowPopup(link) {
		windowPopup(link,450,300);	
}

function windowPopup(url, width, height) {
    var now = new Date
    var name = now.getTime()
	
    // Fixes dual-screen position      Most browsers      Firefox  
    var dualScreenLeft = window.screenLeft != undefined ? window.screenLeft : screen.left;  
    var dualScreenTop = window.screenTop != undefined ? window.screenTop : screen.top;  
              
    var winWidth = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;  
    var winHeight = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height;  
              
    var leftPosition = ((winWidth / 2) - (width / 2)) + dualScreenLeft;  
    var topPosition = ((winHeight / 2) - (height / 2)) + dualScreenTop; 
	
	if(isTablet())
	{
		parent.location = url;
	}
	else
	{
		var newWindow = window.open(url, name, 'resizable=yes,statusbar=no,toolbar=no,menubar=no,scrollbars=no,location=no,directories=no, width=' + width + ', height=' + height + ', top=' + topPosition + ', left=' + leftPosition); 
		
		// Puts focus on the newWindow  
		if (window.focus) {  
			newWindow.focus();  
		}
	}
}

	function isTablet()
	{
		var userAgent = navigator.userAgent.toLowerCase();
		var isTablet = /(ipad|tablet|(android(?!.*mobile))|(windows(?!.*phone)(.*touch))|kindle|playbook|silk|(puffin(?!.*(IP|AP|WP))))/.test(userAgent);
		return isTablet;
	}