function zcheckblank(field)
{
    var inp = eval("document.forms[0]." + field);
	if (typeof(inp) == "undefined") return;
	var i;
	if (inp.length > 0 && inp[0].type != undefined)
	{
		for (i = 0; i < inp.length; i++)
		{
			//alert(inp[i].type + " " + inp[i].checked + " " + inp[i].selected + " " + inp[i].value);
			if (inp[i].type == "radio" && inp[i].checked) return true;
			if (inp[i].type == "checkbox" && inp[i].checked) return true;
			if (inp[i].type == "option" && inp[i].selected) return true;
			if (inp[i].type == "hidden" && !isEmpty(trim(inp[i].value))) return true;
		}
	}
	else
	{
		if (!isEmpty(trim(inp.value)))
			return true;
	}
	return false;
}

function zmult(field1, field2, field3, digits, first, last)
{
    var result = eval("document.forms[0]." + field3);
    var inp1 = eval("document.forms[0]." + field1);
    if (typeof(inp1) == "undefined" || typeof(result) == "undefined")
    {
		return;
    }
	var inp2;
    var val2 = parseFloat(field2);
    var isConst2;
    if (isNaN(val2))
        isConst2 = false;
    else
        isConst2 = true;
    if (!isConst2)
        inp2 = eval("document.forms[0]." + field2);
    if (typeof(result.length) == "undefined")
    {
        if (typeof(inp1.length) == "undefined")
        {
            if (isConst2)
                result.value = convertFloat(inp1.value) * val2;
            else
                result.value = convertFloat(inp1.value) * convertFloat(inp2.value);
            if (isNaN(result.value)) result.value = 0;
        }
        else
        {
            result.value = 0;
 			var start = 0;
			var end = inp1.length;
			if (typeof(first) != "undefined" && first >= start)
				start = first;
			if (typeof(last) != "undefined" && last <= end)
				end = last;
			for (i = start; i < end; i++)
            {
                if (isConst2)
                {
                    result.value = convertFloat(inp1[i].value) * val2;
                }
                else
                {
                    if (typeof(inp2.length) == "undefined")
                        result.value = result.value + (convertFloat(inp1[i].value) * convertFloat(inp2.value));
                    else
                        result.value = result.value + (convertFloat(inp1[i].value) * convertFloat(inp2[i].value));
                }
                if (isNaN(result.value)) result.value = 0;
            }
       }
    }
    else
    {
		var start = 0;
		var end = result.length;
		if (typeof(first) != "undefined" && first >= start)
			start = first;
		if (typeof(last) != "undefined" && last <= end)
			end = last;
		for (i = start; i < end; i++)
		{
            if (typeof(inp1.length) == "undefined")
            {
                if (isConst2)
                    result[i].value = convertFloat(inp1.value) * val2;
                else
                    result[i].value = convertFloat(inp1.value) * convertFloat(inp2.value);
                if (isNaN(result[i].value)) result[i].value = 0;
            }
            else
            {
                if (isConst2)
                {
                    result[i].value = convertFloat(inp1[i].value) * val2;
                }
                else
                {
                    if (typeof(inp2.length) == "undefined")
                        result[i].value = (convertFloat(inp1[i].value) * convertFloat(inp2.value));
                    else
                        result[i].value = (convertFloat(inp1[i].value) * convertFloat(inp2[i].value));
                }
                if (isNaN(result[i].value)) result[i].value = 0;
            }
        }
    }
    if (typeof(digits) != "undefined") roundoff(field3, digits);
}

function zmult3(field1, field2, field3, field4, digits, first, last)
{
    var result = eval("document.forms[0]." + field4);
    var inp1 = eval("document.forms[0]." + field1);
    if (typeof(inp1) == "undefined" || typeof(result) == "undefined")
    {
		return;
    }
	var inp2 = eval("document.forms[0]." + field2);
	var inp3;
    var val3 = parseFloat(field3);
    var isConst3;
    if (isNaN(val3))
        isConst3 = false;
    else
        isConst3 = true;
    if (!isConst3)
        inp3 = eval("document.forms[0]." + field3);
    if (typeof(result.length) == "undefined")
    {
        if (typeof(inp1.length) == "undefined")
        {
            if (isConst3)
                result.value = convertFloat(inp1.value) * convertFloat(inp2.value) * val3;
            else
                result.value = convertFloat(inp1.value) * convertFloat(inp2.value) * convertFloat(inp3.value);
            if (isNaN(result.value)) result.value = 0;
        }
        else
        {
            result.value = 0;
 			var start = 0;
			var end = inp1.length;
			if (typeof(first) != "undefined" && first >= start)
				start = first;
			if (typeof(last) != "undefined" && last <= end)
				end = last;
			for (i = start; i < end; i++)
            {
                if (isConst3)
                {
                    result.value = convertFloat(inp1[i].value) * convertFloat(inp2[i].value) * val3;
                }
                else
                {
                    if (typeof(inp2.length) == "undefined")
                        result.value = result.value + (convertFloat(inp1[i].value) * convertFloat(inp2.value) * convertFloat(inp3.value));
                    else
                        result.value = result.value + (convertFloat(inp1[i].value) * convertFloat(inp2[i].value) * convertFloat(inp3[i].value));
                }
                if (isNaN(result.value)) result.value = 0;
            }
       }
    }
    else
    {
		var start = 0;
		var end = result.length;
		if (typeof(first) != "undefined" && first >= start)
			start = first;
		if (typeof(last) != "undefined" && last <= end)
			end = last;
		for (i = start; i < end; i++)
		{
            if (typeof(inp1.length) == "undefined")
            {
                if (isConst3)
                    result[i].value = convertFloat(inp1.value) * convertFloat(inp2.value) * val3;
                else
                    result[i].value = convertFloat(inp1.value) * convertFloat(inp2.value) * convertFloat(inp3.value);
                if (isNaN(result[i].value)) result[i].value = 0;
            }
            else
            {
                if (isConst3)
                {
                    result[i].value = convertFloat(inp1[i].value) * convertFloat(inp2.value) * val3;
                }
                else
                {
                    if (typeof(inp2.length) == "undefined")
                        result[i].value = (convertFloat(inp1[i].value) * convertFloat(inp2.value) * convertFloat(inp3.value));
                    else
                        result[i].value = (convertFloat(inp1[i].value) * convertFloat(inp2[i].value) * convertFloat(inp3[i].value));
                }
                if (isNaN(result[i].value)) result[i].value = 0;
            }
        }
    }
    if (typeof(digits) != "undefined") roundoff(field3, digits);
}

function zdivide(field1, field2, field3, digits, first, last)
{
    var result = eval("document.forms[0]." + field3);
    var inp1 = eval("document.forms[0]." + field1);
    if (typeof(inp1) == "undefined" || typeof(result) == "undefined")
    {
		return;
    }
	var inp2;
    var val2 = parseFloat(field2);
    var isConst2;
    if (isNaN(val2))
        isConst2 = false;
    else
        isConst2 = true;
    if (!isConst2)
        inp2 = eval("document.forms[0]." + field2);
    if (typeof(result.length) == "undefined")
    {
        if (typeof(inp1.length) == "undefined")
        {
            if (isConst2)
			{
				if (val2 != 0)
                result.value = convertFloat(inp1.value) / val2;
            }
            else
			{
				val2 = convertFloat(inp2.value);
				if (val2 != 0)
					result.value = convertFloat(inp1.value) / val2;
            }
            if (isNaN(result.value)) result.value = 0;
        }
        else
        {
            result.value = 0;
			var start = 0;
			var end = inp1.length;
			if (typeof(first) != "undefined" && first >= start)
				start = first;
			if (typeof(last) != "undefined" && last <= end)
				end = last;
			for (i = start; i < end; i++)
			{
                if (isConst2)
                {
					if (val2 != 0)
                    result.value = convertFloat(inp1[i].value) / val2;
                }
                else
                {
                    if (typeof(inp2.length) == "undefined")
					{
						val2 = convertFloat(inp2.value);
						if (val2 != 0)
							result.value = result.value + (convertFloat(inp1[i].value) / val2);
                    }
                    else
                    {
						val2 = convertFloat(inp2[i].value);
						if (val2 != 0)
							result.value = result.value + (convertFloat(inp1[i].value) / val2);
					}
                }
                if (isNaN(result.value)) result.value = 0;
            }
        }
    }
    else
    {
		var start = 0;
		var end = result.length;
		if (typeof(first) != "undefined" && first >= start)
			start = first;
		if (typeof(last) != "undefined" && last <= end)
			end = last;
		for (i = start; i < end; i++)
        {
            if (typeof(inp1.length) == "undefined")
            {
                if (isConst2)
                    result[i].value = convertFloat(inp1.value) / val2;
                else
                    result[i].value = convertFloat(inp1.value) / convertFloat(inp2.value);
                if (isNaN(result[i].value)) result[i].value = 0;
            }
            else
            {
                if (isConst2)
                {
                    result[i].value = convertFloat(inp1[i].value) / val2;
                }
                else
                {
                    if (typeof(inp2.length) == "undefined")
                        result[i].value = (convertFloat(inp1[i].value) / convertFloat(inp2.value));
                    else
                        result[i].value = (convertFloat(inp1[i].value) / convertFloat(inp2[i].value));
                }
                if (isNaN(result[i].value)) result[i].value = 0;
            }
        }
    }
    if (typeof(digits) != "undefined") roundoff(field3, digits);
}
    
function zadd(field1, field2, field3, digits)
{
    var result = eval("document.forms[0]." + field3);
    var inp1 = eval("document.forms[0]." + field1);
    if (typeof(inp1) == "undefined" || typeof(result) == "undefined")
    {
		return;
    }
    var inp2;
    var val2 = parseFloat(field2);
    var isConst2;
    if (isNaN(val2))
        isConst2 = false;
    else
        isConst2 = true;
    if (!isConst2)
        inp2 = eval("document.forms[0]." + field2);
    if (typeof(result.length) == "undefined")
    {
        if (typeof(inp1.length) == "undefined")
        {
            if (isConst2)
                result.value = convertFloat(inp1.value) + val2;
            else
                result.value = convertFloat(inp1.value) + convertFloat(inp2.value);
            if (isNaN(result.value)) result.value = 0;
        }
        else
        {
            result.value = 0;
            for (i = 0; i < inp1.length; i++)
            {
                if (isConst2)
                {
                    result.value = convertFloat(result.value) + convertFloat(inp1[i].value) + val2;
                }
                else
                {
                    if (typeof(inp2.length) == "undefined")
                        result.value = convertFloat(result.value) + convertFloat(inp1[i].value) + convertFloat(inp2.value);
                    else
                        result.value = convertFloat(result.value) + convertFloat(inp1[i].value) + convertFloat(inp2[i].value);
                }
                if (isNaN(result.value)) result.value = 0;
            }
        }
	}
    else
    {
        for(i = 0; i < result.length; i++)
        {
            if (typeof(inp1.length) == "undefined")
            {
                if (isConst2)
                    result[i].value = convertFloat(inp1.value) + val2;
                else
                    result[i].value = convertFloat(inp1.value) + convertFloat(inp2.value);
                if (isNaN(result[i].value)) result[i].value = 0;
            }
            else
            {
                if (isConst2)
                {
                    result[i].value = convertFloat(inp1[i].value) + val2;
                }
                else
                {
                    if (typeof(inp2.length) == "undefined")
                        result[i].value = convertFloat(inp1[i].value) + convertFloat(inp2.value);
                    else
                        result[i].value = convertFloat(inp1[i].value) + convertFloat(inp2[i].value);
                }
                if (isNaN(result[i].value)) result[i].value = 0;
            }
        }
    }
    if (typeof(digits) != "undefined") roundoff(field3, digits);
}
    
function zsubb(field1, field2, field3, digits)
{
    var result = eval("document.forms[0]." + field3);
    var inp1 = eval("document.forms[0]." + field1);
    if (typeof(inp1) == "undefined" || typeof(result) == "undefined")
    {
		return;
    }
    var inp2;
    var isConst2;
    var val2 = parseFloat(field2);
    if (isNaN(val2))
        isConst2 = false;
    else
        isConst2 = true;
    if (!isConst2)
        inp2 = eval("document.forms[0]." + field2);
    if (typeof(result.length) == "undefined")
    {
        if (typeof(inp1.length) == "undefined")
        {
            if (isConst2)
                result.value = convertFloat(inp1.value) - val2;
            else
                result.value = convertFloat(inp1.value) - convertFloat(inp2.value);
        }
        else
        {
            result.value = 0;
            for (i = 0; i < inp1.length; i++)
            {
                if (isConst2)
                {
                    result.value = convertFloat(result.value) + convertFloat(inp1[i].value) - val2;
                }
                else
                {
                    if (typeof(inp2.length) == "undefined")
                        result.value = convertFloat(result.value) + convertFloat(inp1[i].value) - convertFloat(inp2.value);
                    else
                        result.value = convertFloat(result.value) + convertFloat(inp1[i].value) - convertFloat(inp2[i].value);
                }
            }
        }
        if (isNaN(result.value)) result.value = inp1.value;
        if (isNaN(result.value)) result.value = 0;
    }
    else
    {
        for(i = 0; i < result.length; i++)
        {
            if (typeof(inp1.length) == "undefined")
            {
                if (isConst2)
                    result[i].value = convertFloat(inp1.value) - val2;
                else
                    result[i].value = convertFloat(inp1.value) - convertFloat(inp2.value);
            }
            else
            {
                if (isConst2)
                {
                    result[i].value = convertFloat(inp1[i].value) - val2;
                }
                else
                {
                    if (typeof(inp2.length) == "undefined")
                        result[i].value = convertFloat(inp1[i].value) - convertFloat(inp2.value);
                    else
                        result[i].value = convertFloat(inp1[i].value) - convertFloat(inp2[i].value);
                }
            }
            if (isNaN(result[i].value)) result[i].value = inp1[i].value;
            if (isNaN(result[i].value)) result[i].value = 0;
        }
    }
    if (typeof(digits) != "undefined") roundoff(field3, digits);
}
    
function zcopy(field1, field2)
{
    var out = eval("document.forms[0]." + field2);
    var inp = eval("document.forms[0]." + field1);
    if (typeof(inp) == "undefined" || typeof(out) == "undefined")
    {
		return;
    }
    if (typeof(out.length) == "undefined")
    {
        if (typeof(inp.length) == "undefined")
        {
            out.value = inp.value;
        }
        else
        {
            out.value = "";
            for (i = 0; i < inp.length; i++)
            {
                out.value = out.value + inp[i].value;
            }
        }
    }
    else
    {
        for(i = 0; i < out.length; i++)
        {
            if (typeof(inp.length) == "undefined")
            {
                out[i].value = inp.value;
            }
            else
            {
                out[i].value = inp[i].value;
            }
        }
    }
}
    
function zcopyindex(field1, field2)
{
    var out = eval("document.forms[0]." + field2);
    var inp = eval("document.forms[0]." + field1);
    if (inp == undefined || out == undefined)
    {
		return;
    }
	if (out[0].selectedIndex == undefined)
    {
        if (inp[0].selectedIndex == undefined)
        {
            out.selectedIndex = inp.selectedIndex;
        }
        else
        {
            out.selectedIndex = inp[0].selectedIndex;
        }
    }
    else
    {
		for(i = 0; i < out.length; i++)
        {
            if (inp[0].selectedIndex == undefined)
            {
                out[i].selectedIndex = inp.selectedIndex;
            }
            else
            {
                out[i].selectedIndex = inp[i].selectedIndex;
            }
        }
    }
}
    
function zcopyValue(value, field2, ind)
{
    var out = eval("document.forms[0]." + field2);
    if (typeof(value) == "undefined" || typeof(out) == "undefined")
    {
		return;
    }
    if (typeof(out.length) == "undefined")
    {
		out.value = value;
    }
    else
    {
		if (ind != null)
		{
			out[ind].value = value;
			return;
		}
        for(i = 0; i < out.length; i++)
        {
			out[i].value = value;
        }
    }
}
    
function zsum(field1, field2, digits, first, last)
{
    var result = eval("document.forms[0]." + field2);
    var inp1 = eval("document.forms[0]." + field1);
    if (inp1 == undefined || result == undefined)
    {
		return;
    }
    if (result.length == undefined)
    {
        if (inp1.length == undefined)
        {
            result.value = convertFloat(inp1.value);
            if (isNaN(result.value)) result.value = 0;
        }
        else
        {
            result.value = 0;
			var start = 0;
			var end = inp1.length;
			if (first != undefined && first >= start)
				start = first;
			if (last != undefined && last <= end)
				end = last;
			for (i = start; i < end; i++)
            {
                addval = convertFloat(inp1[i].value);
                if (isNaN(addval)) addval = 0;
                result.value = convertFloat(result.value) + addval;
                if (isNaN(result.value)) result.value = 0;
            }
        }
    }
    else
    {
        for(i = 0; i < result.length; i++)
        {
            if (inp1.length == undefined)
            {
                result[i].value = inp1.value;
            }
            else
            {
                result[i].value = inp1[i].value;
            }
            if (isNaN(result[i].value)) result[i].value = 0;
        }
    }
    if (digits != undefined) roundoff(field2, digits);
}
    
function zmax(field1, field2)
{
    var out = eval("document.forms[0]." + field2);
    var inp = eval("document.forms[0]." + field1);
    if (inp == undefined || out == undefined)
    {
		return;
    }
    if (out.length == undefined)
    {
        if (inp.length == undefined)
        {
            out.value = inp.value;
        }
        else
        {
            out.value = inp[0].value;
            for (i = 0; i < inp.length; i++)
            {
                if (inp[i].value > out.value)
                {
					out.value = inp[i].value;
                }
            }
        }
    }
    else
    {
        for(i = 0; i < out.length; i++)
        {
            if (inp.length == undefined)
            {
                out[i].value = inp.value;
            }
            else
            {
                out[i].value = inp[i].value;
            }
        }
    }
}
    
function zchecksum(field1, field2, operator, name1)
{
	var field = field1.name;
	if (field != null)
	{
		field1 = field1.name;
	}
    var value = field2;
	if (isNaN(value))
	{
		value = eval("document.forms[0]." + field2);
		if (value != null && value != undefined)
		{
			value = value.value;
		}
    }
	var inp1 = eval("document.forms[0]." + field1);
    if (inp1 == undefined || value == undefined)
    {
		return;
    }
	var sum = 0;
	if (inp1.length == undefined)
	{
		sum = convertFloat(inp1.value);
		if (isNaN(sum)) sum = 0;
	}
	else
	{
		for (i = 0; i < inp1.length; i++)
		{
			addval = convertFloat(inp1[i].value);
			if (isNaN(addval)) addval = 0;
			sum = sum + addval;
			if (isNaN(sum)) sum = 0;
		}
	}
	if (operator == "eq" && sum != value)
	{
		alert("The sum of " + name1 + " should be equal to " + value);
	}
	else if (operator == "gt" && sum <= value)
	{
		alert("The sum of " + name1 + " should be greater than " + value);
	}
	else if (operator == "lt" && sum >= value)
	{
		alert("The sum of " + name1 + " should be less than " + value);
	}
	else if (operator == "ge" && sum < value)
	{
		alert("The sum of " + name1 + " should be greater than or equal to " + value);
	}
	else if (operator == "le" && sum > value)
	{
		alert("The sum of " + name1 + " should be less than or equal to " + value);
	}
	else if (operator == "ne" && sum == value)
	{
		alert("The sum of " + name1 + " should not be equal to " + value);
	}
}
    
function zmoney(field, clear, units)
{
    if (clear == undefined) clear = false;
    if (units == undefined || units == null) units = "";
    var inp = eval("document.forms[0]." + field);
    if (inp.length == undefined)
    {
        amount = convertFloat(inp.value);
        if (isNaN(amount))
        {
            if (clear)
            {
                inp.value = "";
                return;
            }
            amount = "0";
        }
        amount = (Math.round(amount*100))/100;
        inp.value = (amount == Math.floor(amount)) ? units + amount + '.00' : units + (  (amount*10 == Math.floor(amount*10)) ? amount + '0' : amount);
    }
    else
    {
        for (i = 0; i < inp.length; i++)
        {
            amount = convertFloat(inp[i].value);
            if (isNaN(amount))
            {
                if (clear)
                {
                    inp[i].value = "";
                    continue;
                }
                amount = "0";
            }
            amount = (Math.round(amount*100))/100;
            inp[i].value = (amount == Math.floor(amount)) ? units + amount + '.00' : units + (  (amount*10 == Math.floor(amount*10)) ? amount + '0' : amount);
        }
    }
}

function roundoff(field, digits)
{
    if (digits == undefined) digits = 2;
     var inp = eval("document.forms[0]." + field);
   var i = 0
	var rval = 1;
	for (i = 0; i < digits; i++)
    {
		rval = rval*10;
    }
	if (inp.length == undefined)
    {
        amount = convertFloat(inp.value);
        if (isNaN(amount))
        {
			inp.value = "";
			return;
            amount = "0";
        }

        inp.value = (Math.round(amount*rval))/rval;
    }
    else
    {
        for (i = 0; i < inp.length; i++)
        {
            amount = convertFloat(inp[i].value);
            if (isNaN(amount))
            {
                if (clear)
                {
                    inp[i].value = "";
                    continue;
                }
                amount = "0";
            }
			inp[i].value = (Math.round(amount*rval))/rval;
        }
    }
}
    
function zcheckrequired(field1, value1, field2, operator)
{
    if (operator == null || operator == undefined)
        operator = "eq";
    var i;
    
    var inp1 = eval("document.forms[0]." + field1);
    var result = eval("document.forms[0]." + field2);
    var rtype = result.type;
    var itype = inp1.type;
    if (result.length == undefined || rtype =='select-one')
    {
        var value = inp1.value;
        if (value == undefined && itype != 'select-one') value = inp1[0].value;
        if (value == undefined && itype == 'select-one') value = inp1.options[inp1.selectedIndex].value;
        if (inp1[0].type == 'radio')
        {
            for (var j = 0; j < inp1.length; j++)
                if (inp1[j].checked) value = inp1[j].value;
        }
        var req = false;
        if (operator == "eq")
            req = (value == value1);
        if (operator == "gt")
            req = (value > value1);
        if (operator == "lt")
            req = (value < value1);
        if (operator == "ge")
            req = (value >= value1);
        if (operator == "le")
            req = (value <= value1);
        if (operator == "ne")
            req = (value != value1);
        if (req && (trim(result.value) == '' || trim(result.value) == '0' || trim(result.value) == '0.00'))
        {
            alert(result.name + " cannot be blank or 0");
            result.focus();
            result.select();
            return;
        }
    }
    else
    {
        for(i = 0; i < result.length; i++)
        {
            var value = inp1.value;
            if (value == undefined && itype != 'select-one') value = inp1[0].value;
            if (value == undefined && itype == 'select-one') value = inp1.options[inp1.selectedIndex].value;
            if (inp1[0].type == 'radio')
            {
                for (var j = 0; j < inp1.length; j++)
                    if (inp1[j].checked) value = inp1[j].value;
            }
            var req = false;
            if (operator == "eq")
                req = (value == value1);
            if (operator == "gt")
                req = (value > value1);
            if (operator == "lt")
                req = (value < value1);
            if (operator == "ge")
                req = (value >= value1);
            if (operator == "le")
                req = (value <= value1);
            if (operator == "ne")
                req = (value != value1);
            if (req && (trim(result[i].value) == '' || trim(result.value) == '0' || trim(result.value) == '0.00'))
            {
                alert(result.name + " cannot be blank or 0");
                result[i].focus();
                return;
            }
        }
    }
}
    
function zsetcondval(field1, value1, field2, value2, operator, field2name)
{
    if (operator == null || operator == undefined)
        operator = "eq";
    var i;
	var inputs1 = document.getElementsByName(field1);
	var inputs2 = document.getElementsByName(value1);
	var results2 = document.getElementsByName(field2);
	if (inputs1 == null || inputs1.length == 0 || results2 == null || results2.length == 0)
	{
		return;
	}
	for (var row = 0; row < inputs1.length ; row++)
	{
	if (inputs2 != null  && inputs2[0] != null && value1.length > 3)
	{
		value1 = inputs2[row].value;
	}
    var inp1 = inputs1[row];
    var result = results2[row];;
    var resultlab = document.getElementById(field2 + "_lab");
    var resultsel = document.getElementById(field2 + "_sel");
    var resultsel2 = document.getElementById(field2 + "_sel2");
	if (inp1 == null || result == null)
		return;
    var rtype = result.type;
    var itype = inp1.type;
	var fld = eval("document.forms[0]." + value2);
    if (result.length == undefined || rtype =='select-one')
    {
        var value = inp1.value;
		if (value == undefined && itype != 'select-one') value = inp1[i].value;
		if (value == undefined && itype == 'select-one') value = inp1.options[inp1.selectedIndex].value;
        if (inputs1.length > 0 && inputs1[0].type == 'radio')
        {
            for (var j = 0; j < inputs1.length; j++)
                if (inputs1[j].checked) value = inputs1[j].value;
        }
        if (inputs1.length > 1 && inputs1[1].type == 'checkbox')
        {
			console.log("inputs1.length: " + inputs1.length  + " inputs1[0].type:" + inputs1[0].type  + " inputs1[1].type:" + inputs1[1].type)
			value = "";
            for (var j = 0; j < inputs1.length; j++)
                if (inputs1[j].checked) value = value + "," + inputs1[j].value;
        }
        var cond = false;
        if (operator == "eq")
            cond = (value == value1);
        if (operator == "gt")
            cond = (value > value1);
        if (operator == "lt")
            cond = (value < value1);
        if (operator == "ge")
            cond = (value >= value1);
        if (operator == "le")
            cond = (value <= value1);
        if (operator == "ne")
            cond = (value != value1);
        if (operator == "like")
            cond = (value.indexOf(value1) != -1);
		console.log("cond: " + cond  + " value2:" + value2  + " value1:" + value1  + " value:" + value  + " label:" + resultlab);
		if (cond && value2 == 'HIDE')
		{
			console.log("Setting " + result.name + " hidden");
			result.style.visibility = 'hidden'
			if (resultlab != null) resultlab.style.visibility = 'hidden'
			if (resultsel != null) resultsel.style.visibility = 'hidden'
			if (resultsel2 != null) resultsel2.style.visibility = 'hidden'
            continue;
		}
		else if (!cond && value2 == 'HIDE')
		{
			console.log("Setting " + result.name + " visible");
			result.style.visibility = 'visible'
			if (resultlab != null) resultlab.style.visibility = 'visible'
			if (resultsel != null) resultsel.style.visibility = 'visible'
			if (resultsel2 != null) resultsel2.style.visibility = 'visible'
            continue;
		}
		else if (cond && value2 == 'REQUIRED')
		{
			console.log("Setting " + result.name + " required");
			var name = result.name;
			if (field2name != null)
				name = field2name;
			setAttributeRequired(result.name, name);
			continue;
		}
		else if (!cond && value2 == 'REQUIRED')
		{
			console.log("Setting " + result.name + " not required");
			setAttributeNotRequired(result.name);
			continue;
		}
		else if (cond && value2.startsWith('COLOR'))
		{
			console.log("Setting " + result.name + " COLOR " + value2.substring(5));
			result.style.backgroundColor = value2.substring(5);
			continue;
		}
		else if (!cond && value2.startsWith('COLOR'))
		{
			console.log("Setting " + result.name + " COLOR to white");
			result.style.backgroundColor = 'white'
			continue;
		}		

		if (cond && value2 == 'READONLY')
		{
			console.log("Setting " + result.name + " readonly");
			if (rtype == 'select-one')
			{
				result.disabled = true;
			}
			result.readOnly = true;
			continue;
		}
		else if (!cond && value2 == 'READONLY')
		{
			console.log("Setting " + result.name + " editable");
			if (rtype == 'select-one')
			{
				result.disabled = false;
			}
			result.readOnly = false
			continue;
		}
		else if (cond)
        {
			if (fld == undefined)
			{
				result.value = value2;
			}
			else
			{
				result.value = fld.value;
			}
            continue;
        }
    }
    else
    {
        for(i = 0; i < result.length; i++)
        {
			var value = inp1.value;
			if (value == undefined && itype != 'select-one') value = inp1[i].value;
			if (value == undefined && itype == 'select-one') value = inp1.options[inp1.selectedIndex].value;
			if (inp1[0].type == 'radio')
            {
                for (var j = 0; j < inp1.length; j++)
                    if (inp1[j].checked) value = inp1[j].value;
            }
            var cond = false;
            if (operator == "eq")
                cond = (value == value1);
            if (operator == "gt")
                cond = (value > value1);
            if (operator == "lt")
                cond = (value < value1);
            if (operator == "ge")
                cond = (value >= value1);
            if (operator == "le")
                cond = (value <= value1);
            if (operator == "ne")
                cond = (value != value1);
			if (cond && value2 == 'HIDE')
			{
				result.style.visibility = 'hidden'
			}
            else if (cond)
            {
				if (fld == undefined)
				{
					result[i].value = value2;
				}
				else
				{
					if (fld.length == undefined || fld.type == 'select-one')
						result[i].value = fld.value;
					else
						result[i].value = fld[i].value;
				}
            }
        }
    }
        if (inputs1.length > 1 && inputs1[1].type == 'checkbox') break;
        if (inputs1.length > 0 && inputs1[0].type == 'radio') break;
	}
}

// convert without check (removes commas)
function convertFloat(val)
{
	if(val.indexOf("$") == 0)
		val = val.substring(1,val.length);
    var i;
    if (val.length > 0)
    {
        for (i = 0; i < val.length; i++)
        {   
            var c = val.charAt(i);
            if (c == ',')
            {
                val = val.substring(0,i) + val.substr(i+1);
            }
        }
    }
	else
		return 0;
    return parseFloat(val)
}
    
function zchildselect(parent, child)
{
    var selParent = eval("document.forms[0]." + parent);
    var selChild = eval("document.forms[0]." + child);
    indParent = selParent.selectedIndex;
    opts = selChild.options;
    n = 0;
    for (i = 0; i < opts.length; i++)
    {
        if (opts[i].text.substr(0,4) != "--- ") continue;
        if (indParent == n)
        {
            selChild.selectedIndex = i;
            break
        }
        n++;
    }
}
    
function zparentselect(parent, child)
{
    var selParent = eval("document.forms[0]." + parent);
    var selChild = eval("document.forms[0]." + child);
        
    indChild = selChild.selectedIndex;
    opts = selChild.options;
    n = -1;
    for (i = 0; i <= indChild; i++)
    {
        if (opts[i].text.substr(0,4) != "--- ") continue;
        n++;
    }
    if (n == -1) n = 0;
    selParent.selectedIndex = n;
}
    
function zchecksize(field, min, max, msg, ind)
{
    var s = field.value;
        
    s = trim(s);
    if (isEmpty(s)) return true;
    if ((s.length >= min) && isEmpty(max)) 
        return true;
    if ((s.length <= max) && isEmpty(min)) 
        return true;
    if ((s.length >= min) && (s.length <= max)) return true;
    if (msg) 
    {
        if (isEmpty(max))
            alert("Value should be at least " + min + " in length");
        else
        {
            if (isEmpty(min))
                alert("Value should not be more than " + max + " in length");
            else
                alert("Value should be between " + min + " and " +  max + " in length");
        }
    }
	if (field.type != 'hidden')
	{
	    field.focus();
	    field.select();
		field.value = field.defaultValue;
    }
    return false;
}
    
function zcheckInvalid(field, invalidList)
{
    var s = field.value;
        
    s = trim(s);
    if (isEmpty(s)) return true;
	if (invalidList.indexOf(",") == -1)
	{
		var fld = eval("document.forms[0]." + invalidList);
		if (fld != undefined)
		{
			invalidList = fld.value;
		}
	}

	if (invalidList != null && invalidList.length > 0)
	{
		invalidList = "," + invalidList + ",";
		if (invalidList.indexOf(s) == -1)
		{
			return true;
		}
	}
	else
	{
		return true;
	}

	alert("Invalid value");
	if (field.type != 'hidden')
    	field.focus();
    if (field.type != 'select-one')
    {
		field.select();
    }
    return false;
}
    
function zcheckValid(field, validList)
{
    var s = field.value;
        
    s = trim(s);
    if (isEmpty(s)) return true;
	if (validList != null && validList.length > 0)
	{
		validList = "," + validList + ",";
		if (validList.indexOf(s) != -1)
		{
			return true;
		}
	}
	alert("Invalid value");
	if (field.type != 'hidden')
	{
	    field.focus();
	    field.select();
	}
    return false;
}

function zaddselval(field, fieldname)
{
	var s = field.value;
	var selind = field.selectedIndex;
	if (s == 'Other...' || s.indexOf('--') == 0)
	{
		newval = prompt("Please enter new value for " + fieldname, '');
		if (newval == null || trim(newval) == '')
		{
			field.options[0].text = "<-- Select -->";
			field.options[0].value = "";
			field.selectedIndex = 0;
		}
		else
		{
			field.selectedIndex = 0;
			field.options[0].text = newval;
			field.options[0].value = newval;
		}
	}
	return;
}
    
function zaddradioval(field, fieldname)
{
	newval = prompt("Please enter new value for " + fieldname, field.value);
	if (trim(newval) != '')
	{
		field.value = "";
	}
	else if (newval != null)
	{
		field.value = newval;
	}
	return;
}
    
function zsetcheckboxvals(field, val0, val1, fieldName, ind)
{
    var element = eval("document.forms[0]." + fieldName);
	var newval = "";
	if (field.checked)
	{
		newval = val1;
	}
	else
	{
		newval = val0;
	}
    if (element.length == undefined)
    {
        if (ind == 0)
			element.value = newval;
	}
    else
    {
        element[ind].value = newval;
    }
}

function zcheckName(field, fieldName)
{
    var s = field.value;
    s = trim(s);
	var tg1=/[\\\/:\*?"<>|]/;
	if ( tg1.test(s) )
	{
		if (fieldName == undefined || fieldName == null)
		{
			fieldName = '';
		}
		alert('Field ' + fieldName + ' cannot contain any of the following characters:\/:*?"<>|');
		if (field.type != 'hidden')
		{
			field.focus();
			field.select();
		}
		return false;
	}
	return true;
}
    
function zcheckint(field, min, max, msg, ind)
{
    var s = field.value;
	field.style.backgroundColor='white';
        
    s = trim(s);
    if (isEmpty(s)) return true;
    if (!isEmpty(min) && isNaN(min))
    {
        min = getFieldValue(min, ind);
    }
    if (!isEmpty(max) && isNaN(max))
    {
        max = getFieldValue(max, ind);
        if (max == 0) 
            max = 999999999;
    }
    for (i = 0; i < s.length; i++)
    {   
        var c = s.charAt(i);
        if (i == 0 && c == '-') continue;
        if (c == ',')
        {
            s = s.substring(0,i) + s.substr(i+1);
            continue;
        }

        if (!isDigit(c))
        {
            if (msg) alert("Invalid integer entered");
			if (field.type != 'hidden')
			{
	            field.focus();
	            field.select();
            }
            return false;
        }
    }
    if (isEmpty(min) && isEmpty(max)) return true;

    var num = parseInt (s, 10);
    if ((num >= min) && isEmpty(max)) 
        return true;
    if ((num <= max) && isEmpty(min)) 
        return true;
    if ((num >= min) && (num <= max)) return true;
	field.style.backgroundColor='orange';
    if (msg) 
    {
        if (isEmpty(max))
            alert("Value should be at least " + min);
        else
        {
            if (isEmpty(min))
                alert("Value should not be more than " + max);
            else
                alert("Value should be between " + min + " and " +  max);
        }
    }
	if (num == 0)
	{
		field.value = "";
	}
	if (field.type != 'hidden')
    	field.focus();
    if (field.type != 'select-one')
		field.select();
	else
		field.value = field.defaultValue;
    return false;
}
    
function zcheckfloat(field, min, max, msg, ind)
{   
	field.style.backgroundColor='white';
    var i;
    var seenDecimalPoint = false;
    var s = field.value;
    s = trim(s);
    if (isEmpty(s)) return true;
	if (s.charAt(0) == '$')
	{
		s = s.substr(1);
		s = trim(s);
	}
    if (isEmpty(s)) return true;

    if (!isEmpty(min) && isNaN(min))
    {
        min = getFieldValue(min, ind);
    }
    if (!isEmpty(max) && isNaN(max))
    {
        max = getFieldValue(max, ind);
        if (max == 0) max = 999999999;
    }
    if (s == '.') return false;
    for (i = 0; i < s.length; i++)
    {   
        var c = s.charAt(i);
        if (i == 0 && c == '-') continue;
        if (!seenDecimalPoint && c == ',')
        {
            s = s.substring(0,i) + s.substr(i+1);
            continue;
        }
        if ((c == '.') && !seenDecimalPoint) seenDecimalPoint = true;
        else 
            if (!isDigit(c)) 
            {
                if (msg) alert("Invalid number entered");
				if (field.type != 'hidden')
				{
	                field.focus();
	                field.select();
                }
                return false;
            }
    }
    if (isEmpty(min)) return true;

    var num = parseFloat (s);
    if ((num >= min) && isEmpty(max)) 
        return true;
    if ((num <= max) && isEmpty(min)) 
        return true;
    if ((num >= min) && (num <= max)) return true;
	field.style.backgroundColor='orange';
    if (msg)
    {
        if (isEmpty(max))
            alert("Value should be at least " + min);
        else
        {
            if (isEmpty(min))
                alert("Value should not be more than " + max);
            else
                alert("Value should be between " + min + " and " +  max);
        }
    }
	if (num == 0)
	{
		field.value = "";
	}
	if (field.type != 'hidden')
	{
	    field.focus();
	    field.select();
		field.value = field.defaultValue;
	}
    return false;
}
    
function zcheckpwd(field1, field2, name, username, policy)
{
    var element1 = eval("document.forms[0]." + field1);
    var val1 = element1.value;
    var element2 = eval("document.forms[0]." + field2);
    var val2 = element2.value;
    if (val1 != val2)
    {
        alert(name + " fields have to match");
        element1.focus();
        element1.select();
        return false;
    }
    
	if (username != null)
	{
		if (val1.indexOf(username) != -1 || username.indexOf(val1) != -1)
		{
			alert("Password does not meet policy requirements - password/username have the same letters");
			return false;
		}
	}
	var commonwords = new Array('welcome','database','account','user','password','oracle','computer','admin'
						,'abcd','abc','def','xyz','asdf','zesati','zflow','zplm','test','system','quote'); 
	if (val1.length != 24 && val1.length != 60)
	{
		var caps = false;
		var numeric = false;
		var small = false;
		var special = false;
        for (i = 0; i < val1.length; i++)
        {   
            var c = val1.charAt(i);
			if(c >= "0" && c <= "9") 
				numeric = true;
			else if(c >= "a" && c <= "z") 
				small = true;
			else if(c >= "A" && c <= "Z") 
				caps = true;
			else
				special = true;
        }
		if (policy && (!numeric || !small || !caps))
		{
			alert("Password does not meet policy requirements - at least one smallcase/uppercase/numeric");
			return false;
		}

		for (i = 0; i < commonwords.length ; i++)
		{
			if (policy && val1.toLowerCase().indexOf(commonwords[i]) != -1)
			{
				alert("Password does not meet policy requirements - contains common or system words");
				return false;
			}
		}

		if(typeof(document.forms[0].PwdExpired) != "undefined")
			document.forms[0].PwdExpired[0].checked = true;
		if(typeof(document.forms[0].PwdDate) != "undefined" &&
			element1.defaultValue != element1.value)
			document.forms[0].PwdDate.value = getDateStr(new Date());
	}
    return true;
}    

function getFieldValue(field, ind)
{
    var element = eval("document.forms[0]." + field);
    var val;
    if (element.length == undefined || element.type =='select-one')
    {
        val = element.value;
    }
    else
    {
        val = element[ind].value;
    }
    if (val.length > 0)
    {
        for (i = 0; i < val.length; i++)
        {   
            var c = val.charAt(i);
            if (c == ',')
            {
                val = val.substring(0,i) + val.substr(i+1);
            }
        }
    }
    val = parseFloat(val);
    if (isNaN(val)) val = 0;
    return val;
}
    
function zgetValue(field, ind)
{
    var element = eval("document.forms[0]." + field);
    var val;
    if (element.length == undefined || element.type =='select-one')
    {
        if (ind == 0)
			val = element.value;
		else
			val = null;
	}
    else
    {
        val = element[ind].value;
    }
    return val;
}
    
function zputValue(field, ind, val)
{
    var element = eval("document.forms[0]." + field);
    var val;
    if (element.length == undefined || element.type =='select-one')
    {
		if (ind == 0)
			element.value = val;
    }
    else
    {
        element[ind].value = val;
    }
}
    
function zcheckdate(field, min, max, msg, ind)
{
    var i;
    var s = field.value;
    s = trim(s);
    if (isEmpty(s)) return true;
    var minval;
    var maxval;
    if (!isEmpty(min))
    {
        if (typeof(min) == "string")
            minval = parseDate(min);
        if (typeof(min) == "Date")
            minval = min.getTime();
        if (minval == -1)
            minval = getFieldTime(min, ind);
    }
    if (minval == undefined || minval == -1) minval = 0;
    
    if (!isEmpty(max))
    {
        if (typeof(max) == "string")
            maxval = parseDate(max);
        if (typeof(max) == "Date")
            maxval = max.getTime();
        if (maxval == -1)
            maxval = getFieldTime(max, ind);
    }
    if (maxval == undefined || maxval == 0 || maxval == -1)
        maxval = Date.parse('Dec 31, 2999');

    time = parseDate(s);
    if (time == -1)
    {
        if (msg) alert("Invalid date entered");
        field.focus();
        field.select();
        return false;
    }
    if (isEmpty(min) && (time <= maxval)) 
        return true;

    if ((time >= minval) && isEmpty(max)) 
        return true;

    if ((time >= minval) && (time <= maxval)) return true;

    mindate = new Date();
    mindate.setTime(minval);
    maxdate = new Date();
    maxdate.setTime(maxval);
    if (msg)
    {
        if (isEmpty(max))
            alert("Date should be after " + getDateStr(mindate));
        else
        {
            if (isEmpty(min))
                alert("Date should be before " + getDateStr(maxdate));
            else
                alert("Date should be between " + getDateStr(mindate) + " and " +  getDateStr(maxdate));
        }
    }
	if (field.type != 'hidden')
    	field.focus();
    field.value = field.defaultValue;
    return false;
}

function zcheckemail (field, msg)
{
    var s = field.value;
    s = trim(s);
	if (isEmpty(s))
		return true;
    
    // there must be >= 1 character before @, so we
    // start looking at character position 1 
    // (i.e. second character)
    var i = 1;
    var sLength = s.length;

    // look for @
    while ((i < sLength) && (s.charAt(i) != "@"))
    { i++
    }

    if ((i >= sLength) || (s.charAt(i) != "@")) 
	{
		if (msg) alert("Invalid email address entered");
        if (field.type != "hidden")
        {
			field.focus();
			field.select();
		}
        return false;
    }
    else i += 2;

    // look for .
    while ((i < sLength) && (s.charAt(i) != "."))
    { i++
    }

    // there must be at least one character after the .
    if ((i >= sLength - 1) || (s.charAt(i) != ".") || s.indexOf(' ') != -1)
	{
		if (msg) alert("Invalid email address entered");
        if (field.type != "hidden")
        {
			field.focus();
			field.select();
		}
        return false;
    }
    
	field.value = field.value.toLowerCase();
	return true;
} 

function zToUpperCase(field)
{
	var s = field.value;
	if (field.value == null)
		return;
	field.value = field.value.toUpperCase();
}

function zToLowerCase(field)
{
	var s = field.value;
	if (field.value == null)
		return;
	field.value = field.value.toLowerCase();
}

function zdatesub(field1, field2, field3)
{
    var result = eval("document.forms[0]." + field3);
	if (result == null && field3.indexOf("_") != -1)
	{
		field3 = field3.substring(field3.indexOf("_")+1);
		result = eval("document.forms[0]." + field3);
    }
	var inp1 = eval("document.forms[0]." + field1);
	if (inp1 == null && field1.indexOf("_") != -1)
	{
		field1 = field1.substring(field1.indexOf("_")+1);
		inp1 = eval("document.forms[0]." + field1);
    }
	var inp2 = eval("document.forms[0]." + field2);
	if (inp2 == null && field2.indexOf("_") != -1)
	{
		field2 = field2.substring(field2.indexOf("_")+1);
		inp2 = eval("document.forms[0]." + field2);
    }
    if (result.length == undefined)
    {
        if (inp1.value != '' && inp2.value != '')
        {
            msecs = parseDate(inp1.value) - parseDate(inp2.value);
            if (isNaN(msecs)) msecs = 0;
            result.value = Math.floor((msecs/86400000) + 0.5);
        }
        else
            result.value = '';
    }
    else
    {
        for(i = 0; i < result.length; i++)
        {
            if (inp1.length == undefined)
            {
                if (inp1.value != '' && inp2.value != '')
                {
                    msecs = parseDate(inp1.value) - parseDate(inp2.value);
                    if (isNaN(msecs)) msecs = 0;
                    result[i].value = Math.floor((msecs/86400000) + 0.5);
                }
                else
                    result[i].value = '';
            }
            else
            {
                if (inp1[i].value != '' && inp2[i].value != '')
                {
                    msecs = parseDate(inp1[i].value) - parseDate(inp2[i].value);
                    if (isNaN(msecs)) msecs = 0;
                    result[i].value = Math.floor((msecs/86400000) + 0.5);
                }
                else
                    result[i].value = '';
            }
            if (isNaN(result[i].value)) result[i].value = '';
        }
    }
       
}

function ztruncdate(field)
{
    var datestr;
	var time = parseDate(field);
	if (time == -1)
	{
		var inp = eval("document.forms[0]." + field);
		if (inp == null)
		{
			//alert("Invalid field:" + field);
			return '1970/01/01';
		}
		var datestr = inp.value;
	}
	else
		datestr = field;

	if (datestr.indexOf(":") != -1)
	{
		ind = datestr.lastIndexOf(" ");
		if (ind != -1)
		{
			datestr = datestr.substring(0, ind);
		}
		return datestr;
	}
	return datestr;
}

function zdisable(field)
{
    var out = eval("document.forms[0]." + field);
	if (out == null || out == undefined)
	{
		return;
	}
    if (out.length == undefined)
    {
		out.disabled = true;
    }
    else
    {
        for(i = 0; i < out.length; i++)
        {
			out[i].disabled = true;
        }
    }
}
    
function zenable(field)
{
    var out = eval("document.forms[0]." + field);
	if (out == null || out == undefined)
	{
		return;
	}
    if (out.length == undefined)
    {
		out.disabled = false;
    }
    else
    {
        for(i = 0; i < out.length; i++)
        {
			out[i].disabled = false;
        }
    }
}

function zsetval(field, value, index)
{
    var out = eval("document.forms[0]." + field);
    if (out.length == undefined && (index == null || index == 0))
    {
		out.value = value;
    }
    else
    {
        for(i = 0; i < out.length; i++)
        {
			if (index == null || index == i)
			out[i].value = value;
        }
    }
}

function zconcat(result, input1, input2, input3)
{
    var out = eval("document.forms[0]." + result);
    var in1 = eval("document.forms[0]." + input1);
    var in2 = eval("document.forms[0]." + input2);
    var in3 = null;
	if (input3 != null && input3 != '')
	{
		in3 = eval("document.forms[0]." + input3);
	}
    if (out.length == undefined || out.type =='select-one')
    {
		var val = in1.value + in2.value;
		if (in3 != null)
		{
			val = val + in3.value;
		}
		out.value = val;
	}
    else
    {
		var val = null;
		for (i = 0; i < out.length ; i++)
		{
			if (in1.length == null || in1.length == undefined)
			{
				val = in1.value;
			}
			else
			{
				val = in1[i].value;
			}
			if (in2.length == null || in2.length == undefined)
			{
				val = val + in2.value;
			}
			else
			{
				val = val + in2[i].value;
			}
			if (in3 != null)
			{
				if (in3.length == null || in3.length == undefined)
				{
					val = val + in3.value;
				}
				else
				{
					val = val + in3[i].value;
				}
			}
			out[i].value = val;
		}
	}
    return val;
}

function parseDate(str)
{
    s = trim(str);
    if (isEmpty(s)) return -1;
    format = JS_dateformat;
    if (format == undefined) format = "YYYY.MONTH.DD";
    var mon = -1;
    var smon;
    var day;
    var year;
    switch (format) {
	    case "MM\/DD\/YYYY" :
            sarray = s.split("\/");
            mon = parseInt(sarray[0],10);
            day = parseInt(sarray[1],10);
            year = parseInt(sarray[2],10);
		    break;
	    case "MM\/DD\/YY" :
            sarray = s.split("\/");
            mon = parseInt(sarray[0],10);
            day = parseInt(sarray[1],10);
            year = parseInt(sarray[2],10);
		    break;
	    case "MM-DD-YYYY" :
            sarray = s.split("-");
            mon = parseInt(sarray[0],10);
            day = parseInt(sarray[1],10);
            year = parseInt(sarray[2],10);
		    break;
	    case "MM-DD-YY" :
            sarray = s.split("-");
            mon = parseInt(sarray[0],10);
            day = parseInt(sarray[1],10);
            year = parseInt(sarray[2],10);
		    break;

	    case "DD\/MON\/YYYY" :
            sarray = s.split("\/");
            day = parseInt(sarray[0],10);
            smon = sarray[1];
            year = parseInt(sarray[2],10);
		    break;
	    case "DD\/MON\/YY" :
            sarray = s.split("\/");
            day = parseInt(sarray[0],10);
            smon = sarray[1];
            year = parseInt(sarray[2],10);
		    break;
	    case "DD-MON-YYYY" :
            sarray = s.split("-");
            day = parseInt(sarray[0],10);
            smon = sarray[1];
            year = parseInt(sarray[2],10);
		    break;
	    case "DD-MON-YY" :
            sarray = s.split("-");
            day = parseInt(sarray[0],10);
            smon = sarray[1];
            year = parseInt(sarray[2],10);
		    break;

	    case "DD\/MONTH\/YYYY" :
            sarray = s.split("\/");
            day = parseInt(sarray[0],10);
            smon = sarray[1];
            year = parseInt(sarray[2],10);
		    break;
	    case "DD\/MONTH\/YY" :
            sarray = s.split("\/");
            day = parseInt(sarray[0],10);
            smon = sarray[1];
            year = parseInt(sarray[2],10);
		    break;
	    case "DD-MONTH-YYYY" :
            sarray = s.split("-");
            day = parseInt(sarray[0],10);
            smon = sarray[1];
            year = parseInt(sarray[2],10);
		    break;
	    case "DD-MONTH-YY" :
            sarray = s.split("-");
            day = parseInt(sarray[0],10);
            smon = sarray[1];
            year = parseInt(sarray[2],10);
		    break;

	    case "DD\/MM\/YYYY" :
            sarray = s.split("\/");
            day = parseInt(sarray[0],10);
            mon = parseInt(sarray[1],10);
            year = parseInt(sarray[2],10);
		    break;
	    case "DD\/MM\/YY" :
            sarray = s.split("\/");
            day = parseInt(sarray[0],10);
            mon = parseInt(sarray[1],10);
            year = parseInt(sarray[2],10);
		    break;
	    case "DD-MM-YYYY" :
            sarray = s.split("-");
            day = parseInt(sarray[0],10);
            mon = parseInt(sarray[1],10);
            year = parseInt(sarray[2],10);
		    break;
	    case "DD-MM-YY" :
            sarray = s.split("-");
            day = parseInt(sarray[0],10);
            mon = parseInt(sarray[1],10);
            year = parseInt(sarray[2],10);
		    break;

	    case "YYYY\/MONTH\/DD" :
            sarray = s.split("\/");
            year = parseInt(sarray[0],10);
            smon = sarray[1];
            day = parseInt(sarray[2],10);
		    break;
	    case "YYYY\/MM\/DD" :
            sarray = s.split("\/");
            year = parseInt(sarray[0],10);
            mon = parseInt(sarray[1],10);
            day = parseInt(sarray[2],10);
		    break;
	    case "YY\/MONTH\/DD" :
            sarray = s.split("\/");
            year = parseInt(sarray[0],10);
            smon = sarray[1];
            day = parseInt(sarray[2],10);
		    break;
	    case "YY\/MM\/DD" :
            sarray = s.split("\/");
            year = parseInt(sarray[0],10);
            mon = parseInt(sarray[1],10);
            day = parseInt(sarray[2],10);
		    break;
	    case "YYYY.MONTH.DD" :
            sarray = s.split(".");
            year = parseInt(sarray[0],10);
            smon = sarray[1];
            day = parseInt(sarray[2],10);
		    break;
	    case "YY.MONTH.DD" :
            sarray = s.split(".");
            year = parseInt(sarray[0],10);
            smon = sarray[1];
            day = parseInt(sarray[2],10);
		    break;

	    default :
            sarray = s.split("\/");
            mon = parseInt(sarray[0],10);
            day = parseInt(sarray[1],10);
            year = parseInt(sarray[2],10);
    }
    if (isNaN(mon) || isNaN(year) || isNaN(day))
    {
        return -1;
    }
    
    if (mon == -1)
    {
        smon = smon.substring(0,3).toUpperCase();
        if (smon == "JAN") mon = 0;
        if (smon == "FEB") mon = 1;
        if (smon == "MAR") mon = 2;
        if (smon == "APR") mon = 3;
        if (smon == "MAY") mon = 4;
        if (smon == "JUN") mon = 5;
        if (smon == "JUL") mon = 6;
        if (smon == "AUG") mon = 7;
        if (smon == "SEP") mon = 8;
        if (smon == "OCT") mon = 9;
        if (smon == "NOV") mon = 10;
        if (smon == "DEC") mon = 11;
    }
    else
    {
        mon = mon - 1;
    }
    
    if (mon == -1)
    {
        return -1;
    }
    var dateval = new Date(1900,0,1);
    dateval.setYear(year);
    dateval.setMonth(mon);
    dateval.setDate(day);
    ind = s.lastIndexOf(" ");
    var hr = 0;
    var min = 0;
    var sec = 0;
    if (ind != -1)
    {
        t = s.substr(ind+1)
        sarray = t.split(":");
        hr = parseInt(sarray[0],10);
        min = parseInt(sarray[1],10);
        sec = parseInt(sarray[2],10);
    }
    dateval.setHours(hr);
    dateval.setMinutes(min);
    dateval.setSeconds(sec);
    time = dateval.getTime();
    return time;
}

function getDateStr(date, format)
{
    if (typeof(date) != "object")
        return "";
    if (format == null || format == undefined)
		format = JS_dateformat;
    if (format == undefined) format = "YYYY.MONTH.DD";
    var str;
    var vMonth = date.getMonth()+1;
    var vFMon = months[date.getMonth()];
    var vMon = vFMon.substr(0,3);
    var vDD = date.getDate();
    var vY4 = date.getFullYear();
    var vY2 = vY4 - 2000;
    if (vY2 < 0) vY4 + 1;
	vY2 = ( vY2 < 10 ) ? "0"+ Math.round(vY2) : Math.round(vY2);
	vMonth = ( vMonth < 10 ) ? "0"+ Math.round(vMonth) : Math.round(vMonth);
	vDD = ( vDD < 10 ) ? "0"+ Math.round(vDD) : Math.round(vDD);
	switch (format) {
		case "MM\/DD\/YYYY" :
			str = vMonth + "\/" + vDD + "\/" + vY4;
			break;
		case "MM\/DD\/YY" :
			str = vMonth + "\/" + vDD + "\/" + vY2;
			break;
		case "MM-DD-YYYY" :
			str = vMonth + "-" + vDD + "-" + vY4;
			break;
		case "MM-DD-YY" :
			str = vMonth + "-" + vDD + "-" + vY2;
			break;

		case "DD\/MON\/YYYY" :
			str = vDD + "\/" + vMon + "\/" + vY4;
			break;
		case "DD\/MON\/YY" :
			str = vDD + "\/" + vMon + "\/" + vY2;
			break;
		case "DD-MON-YYYY" :
			str = vDD + "-" + vMon + "-" + vY4;
			break;
		case "DD-MON-YY" :
			str = vDD + "-" + vMon + "-" + vY2;
			break;

		case "DD\/MONTH\/YYYY" :
			str = vDD + "\/" + vFMon + "\/" + vY4;
			break;
		case "DD\/MONTH\/YY" :
			str = vDD + "\/" + vFMon + "\/" + vY2;
			break;
		case "DD-MONTH-YYYY" :
			str = vDD + "-" + vFMon + "-" + vY4;
			break;
		case "DD-MONTH-YY" :
			str = vDD + "-" + vFMon + "-" + vY2;
			break;

		case "DD\/MM\/YYYY" :
			str = vDD + "\/" + vMonth + "\/" + vY4;
			break;
		case "DD\/MM\/YY" :
			str = vDD + "\/" + vMonth + "\/" + vY2;
			break;
		case "DD-MM-YYYY" :
			str = vDD + "-" + vMonth + "-" + vY4;
			break;
		case "DD-MM-YY" :
			str = vDD + "-" + vMonth + "-" + vY2;
			break;

		case "YYYY\/MONTH\/DD" :
			str = vY4 + "\/" + vFMon + "\/" + vDD;
			break;
		case "YYYY\/MM\/DD" :
			str = vY4 + "\/" + vMonth + "\/" + vDD;
			break;
		case "YY\/MONTH\/DD" :
			str = vY2 + "\/" + vFMon + "\/" + vDD;
			break;
		case "YY\/MM\/DD" :
			str = vY2 + "\/" + vMonth + "\/" + vDD;
			break;
		case "YYYY.MONTH.DD" :
			str = vY4 + "." + vFMon + "." + vDD;
			break;
		case "YY.MONTH.DD" :
			str = vY2 + "." + vFMon + "." + vDD;
			break;

		default :
			str = vMonth + "\/" + vDD + "\/" + vY4;
	}
	//alert("Date:" + date + " format:" + format + " str:" + str);

	return str;
}

function getDateTimeStr(date)
{
    str = getDateStr(date);
    str = str + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
    return str;
}

function transDateStr(dateStr, newFormat)
{
	var time = parseDate(dateStr);
	if (time == -1)
	{
		return "";
	}
    var date = new Date();
    date.setTime(time);
	var newdateStr = getDateStr(date, newFormat);
	return newdateStr
}

function getFieldTime(field, ind)
{
    var element = eval("document.forms[0]." + field);
	if (element == null)
	{
		if (field.indexOf("_") != -1)
		{
			field = field.substring(field.indexOf("_")+1);
			element = eval("document.forms[0]." + field);
		}
		if (element == null)
		{
			//alert("Invalid field:" + field);
			return 0;
		}
	}
    var val;
    if (element.length == undefined)
    {
        val = parseDate(element.value);
    }
    else
    {
        val = parseDate(element[ind].value);
    }
    if (isNaN(val)) val = 0;
    return val;
}

function setFileData(field)
{
	if (field.type == "file")
	{
		if (field.value != "")
		{
			var form = eval("document.forms[0]");
			if (form.action.indexOf("filedata") == -1)
			{
				form.action = form.action + "&filedata=true";
				form.encoding = "multipart/form-data";
			}
		}
	}
}

function trim(s)
{
    if (isEmpty(s)) return s;
    while(s.charAt(0)==' ')
        s = s.substr(1);
    while(''+ s.charAt(s.length-1) ==' ')
        s =s.substring(0,s.length-1);
    return s;
}
    
function isEmpty(s)
{   return ((s == null) || (s.length == 0))
}

function isDigit (c)
{   return ((c >= "0") && (c <= "9"))
}

function closeForm() {
	if (window == top)
	{
		window.close();
	}
	else
		window.location = "blank.html"
    return false ;
}

function selectQueryData(base,rowno, cls, subTitle, searchAttr, resultAttr, returnAttr, whereAttr, layerName)
{
// example: 
//0 base=base URL
//1 rowno=1
//2 cls='VendorList'
//3 subTitle='Search Vendor'
//4 searchAttr='ID,Name'
//5 resultAttr='ID,Name,Address'
//6 returnAttr='PRItem_VendorID,PRItem_VendorName,PRItem_VendorAddress'
//7 whereAttr='Division=G/A Sales' considered as default search condition with like clause.
//8 layerName='No,VendorName0,No' here Name is a layer and other two are not, so the order of the layer
//			has to be given by specifying others as 'No'

	var link = base + "/jsp/mainframe.jsp?wintitle=Search Query&command=query&type=selectItem&rowno="+rowno+ "&reqsrc=collab_form.jsp&jspname=Search_form&searchAttr=" + searchAttr + "&resultAttr=" + resultAttr + "&returnAttr=" + returnAttr + "&whereAttr=" + whereAttr + "&layerName=" + layerName + "&cls="+cls+"&subTitle="+ escape(subTitle);
	javascript:viewWindow(link);
}

//Settting to one of the Row Item
function setRowItem(fieldName, fieldValue,rowno)
{
//		alert(fieldName+" "+fieldValue+" "+rowno);
	var elems = thisform.elements;
	var index=0;
	for (i=0;i < elems.length; i++)
	{
		if ( fieldName == elems[i].name )
		{
			if ( rowno == index )
			{
				elems[i].value = fieldValue;
				break;
			} else {
				index ++;
			}
		}
	}	
}

//Settint to Single Item
function setSingleItem(fieldName, fieldValue)
{
	var elems = thisform.elements;
	for (i=0;i < elems.length; i++)
	{
		if (fieldName == elems[i].name)
		{
			if(elems[i].type != "radio")
			elems[i].value = fieldValue;
			else
			{
				if(elems[i].value == fieldValue)
					elems[i].checked = true;				
			}
		}
	}	
}

function tooltip(jsobj, tip) 
{
    jsobj.title=tip;
    return;
}

function isNumber(str, msg){
	var number = parseFloat(str);
	if(!isNaN(number)){
		return true;
	}	
	if(msg){
		alert(msg);
	}
	return false;
}
    
function zcheckhiloByName(fieldName, min, max, msg, ind, promp)
{
    var field = eval("document.forms[0]." + fieldName);
	return zcheckhilo(field, min, max, msg, ind, promp);
}
    
function zcheckhilo(field, min, max, msg, ind, promp)
{   
	if (promp == null || typeof(promp) == 'undefined') promp = true;
    var i;
    var seenDecimalPoint = false;
    var s = field.value;
    s = trim(s);
    if (isEmpty(s)) return true;
	if (s.charAt(0) == '$')
	{
		s = s.substr(1);
		s = trim(s);
	}
	console.log("val:" + s + " min:" + min + " max:" + max);
    if (isEmpty(s)) return true;

    if (!isEmpty(min) && isNaN(min))
    {
        min = getFieldValue(min, ind);
    }
    if (!isEmpty(max) && isNaN(max))
    {
        max = getFieldValue(max, ind);
        if (max == 0) max = 999999999;
    }

    if (s == '.') return false;
    for (i = 0; i < s.length; i++)
    {   
        var c = s.charAt(i);
        if (i == 0 && c == '-') continue;
        if (!seenDecimalPoint && c == ',')
        {
            s = s.substring(0,i) + s.substr(i+1);
            continue;
        }
        if ((c == '.') && !seenDecimalPoint) seenDecimalPoint = true;
        else 
            if (!isDigit(c)) 
            {
                if (msg) alert("Invalid number entered");
				if (field.type != 'hidden')
				{
	                field.focus();
	                field.select();
                }
                return false;
            }
    }
    if (isEmpty(min)) return true;

    var num = parseFloat (s);
	console.log("val:" + num + " min:" + min + " max:" + max);
	field.style.backgroundColor = 'white';
    if ((num >= min) && isEmpty(max)) 
        return true;
    if ((num <= max) && isEmpty(min)) 
        return true;
    if ((num >= min) && (num <= max)) return true;
    if (msg)
    {
        if (isEmpty(max))
        {
			field.style.backgroundColor = 'yellow';
			if (promp)
			{
				alert("Value should be at least " + min);
			}
        }
		else
        {
			if (isEmpty(min))
            {
 				field.style.backgroundColor = 'red';
				if (promp)
				{
					alert("Value should not be more than " + max);
				}
            }
			else
            {
				if (num < min)
				{
 					field.style.backgroundColor = 'yellow';
				}
				else
				{
 					field.style.backgroundColor = 'red';
				}
				if (promp)
				{
					alert("Value should be between " + min + " and " +  max);
				}
			}
        }
    }
	if (num == 0)
	{
		field.value = "";
	}
	if (field.type != 'hidden')
	{
	    //field.focus();
	    //field.select();
		//field.value = field.defaultValue;
	}
    return false;
}

function zinitField(fieldName)
{
    var field = eval("document.forms[0]." + fieldName);
	var orig = field.defaultValue
	if (orig == "" || orig.indexOf("__") == -1)
	{
		return;
	}
	var start = orig.substring(0,orig.indexOf("__"));
	var orig = orig.substring(orig.indexOf("__")+2);
	if (orig.indexOf("__") == -1)
		return;
	var src = orig.substring(0, orig.indexOf("__"));
	var end = orig.substring(orig.indexOf("__") + 2);
	src = eval("document.forms[0]." + src);
	if (src == null) return;
	srcval = src.value;
	field.value = start + srcval + end;
}
