  function ToRight(left,right){
    countL=0;//total of unselected item on the left side
    countR=0;//total of selected item on the right side
    flag=0;//whether the item already on the right side(selected)
   
   lengthS=left.length;
   //record the numbers of the non-empty item on the right side
   for(n=1;n<lengthS;n++){
    if(right.options[n] && !right.options[n].text == "")
      countR=countR+1;
    }
    
   for(n=1;n<lengthS;n++){
    if(!left.options[n].selected)
      countL=countL+1;
    else {
    
    //check if the item is already selected (already on right side)
     for(j=1;j<lengthS;j++)
        if(right.options[j] && right.options[j].text==left.options[n].text && left.options[n].text != 'break'){
           countL=countL+1;
           flag=1;
           break;
         } 
    //if item is new selected
    if(flag==0)
	{
     right.options[n-countL+countR].text=left.options[n].text;
     right.options[n-countL+countR].value=left.options[n].value;
	}
    if(flag==1)//reset flag
      flag=0;
       
     }//end else
    } //end for
    
    
   //reset left 
   for(n=0;n<lengthS;n++){
     left.options[n].selected=false;
   }
   setVal(right);
  }
   
  function ToLeft(left,right){
	   lengthS=right.length;
	   var count1=0;

	   for(i=lengthS-1;i>0;i--){
			if(right.options[i].selected)
            {
			   for (j = i+1 ; j < lengthS; j++)
			   {
			    right.options[j-1].text=right.options[j].text;
			    right.options[j-1].value=right.options[j].value;
			   }
			    right.options[j-1].text="";
			    right.options[j-1].value="";
			}
	   } 
	   for(i=0;i<lengthS;i++){
		  right.options[i].selected=false;
	   }
   setVal(right);
 }

 function moveUp(obj)
 {
	count=obj.length;
	sCount=0;

	for(c=0;c<count;c++)
	{
		if(obj.options[c].selected)
		{
			sCount=sCount+1;
		}
	}

	for(i=1;i<count;i++)
	{
		if(obj.options[i].selected && i > 1 && obj.options[i].text != "")
		{
			temp=obj.options[i].text;
			tempv=obj.options[i].value;
			obj.options[i].text=obj.options[i-1].text;
			obj.options[i].value=obj.options[i-1].value;
			obj.options[i-1].text=temp;
			obj.options[i-1].value=tempv;
			obj.options[i].selected=false;
			obj.options[i-1].selected=true;
		}
	}
	setVal(obj);
 }

  function moveDown(obj)
 {
	count=obj.length;
	for(i=1;i<count;i++)
	{
		if(obj.options[i].selected && obj.options[i+1].text != "" &&  obj.options[i].text != "")
		{
			temp=obj.options[i].text;
			tempv=obj.options[i].value;
			obj.options[i].text=obj.options[i+1].text;
			obj.options[i].value=obj.options[i+1].value;
			obj.options[i+1].text=temp;
			obj.options[i+1].value=tempv;
			obj.options[i].selected=false;
			obj.options[i+1].selected=true;
			break;
		}
	}
	setVal(obj);
 }

function singleToRight(left,right)
{
    countL=0;//total of unselected item on the left side
    countR=0;//total of selected item on the right side
    flag=0;//whether the item already on the right side(selected)
   
   lengthS=left.length;
   //record the numbers of the non-empty item on the right side
   for(n=1;n<lengthS;n++){
    if(right.options[n] && !right.options[n].text == "")
      countR=countR+1;
    }
    
   for(n=1;n<lengthS;n++){
    if(!left.options[n].selected)
      countL=countL+1;
    else {
    
    //check if the item is already selected (already on right side)
     for(j=1;j<lengthS;j++)
        if(right.options[j] && right.options[j].text==left.options[n].text){
           countL=countL+1;
           flag=1;
           break;
         } 
    //if item is new selected
    if(flag==0)
	{
     right.options[1].text=left.options[n].text;
     right.options[1].value=left.options[n].value;
	}
    if(flag==1)//reset flag
      flag=0;
       
     }//end else
    } //end for
    
    
   //reset left 
   for(n=0;n<lengthS;n++){
     left.options[n].selected=false;
   }
   setVal(right);
}

 function setVal(obj)
 {
	if ( obj.options.length >= 2 )
	{
		order = obj.options[1].value;
		for(i=2;i<obj.length;i++)
		{
			if(obj.options[i].value != "" && obj.options[i].value != "0")
			{
				order =  order + "," + obj.options[i].value ;
			}
		}
		if (document.updFrm != 'undefined' && document.updFrm != null)
			document.updFrm.order.value = order;

	}
 }

 function setHome(thisform)
 {
		for (i=0; i < thisform.available.length; i++)
    	{
			if ( thisform.available[i].checked ) {
				if ( thisform.available[i].value != "other")
					document.updFrm.order.value = thisform.available[i].value;
				else 
					document.updFrm.order.value = thisform.other.value;
			}
		}	
 }