
	function setDataPanel(link)
	{
		var theFrame = document.getElementById('collab_data_frame');
		theFrame.src = link;
	}
	
	function setDataPanelVal(varname, varval)
	{
		var theFrame = document.getElementById('collab_data_frame').contentWindow;
		theFrame.varname = varval;
	}
	
	function selectTreeItem(id, name)
	{
		var theFrame = document.getElementById('collab_tree_frame').contentWindow;
		theFrame.reselect(id,name);
	}
	
	function setTreeIconPanel(content)
	{
		getContent("actions_inline_horizontal.jsp?panel_id=collab_tree_frame&winName=" + window.name + content,"_collab_tree_icon_panel");		
	}
	
	function setDataIconPanel(content)
	{
		getContent("actions_inline_horizontal.jsp?panel_id=collab_data_frame&winName=" + window.name + content,"_collab_data_icon_panel");		
	}
	
	function execFunc(panel_id, jFunc, params)
	{
		var theFrame = document.getElementById(panel_id).contentWindow;
		theFrame.eval(jFunc + "(" + params + ")");	
	}
	
	function clearDataIconPanel()
	{
		document.getElementById("_collab_data_icon_panel").innerHTML='';
	}
	
	function refreshDataPanel()
	{
		var theFrame = document.getElementById('collab_data_frame').contentWindow;
		theFrame.reload;
	}

	function refreshTreePanel()
	{
		var theFrame = document.getElementById('collab_tree_frame').contentWindow;
		theFrame.reload;
	}

	function refreshAsNeeded()
	{
		document.getElementById("floatframe").style.display = 'none';
		var theFrame = document.getElementById('collab_tree_frame').contentWindow;
		theFrame.refreshAsNeeded(selId,selName,selPath);		
	}
	
	function setFolderID()
	{
		var theFrame = document.getElementById('collab_tree_frame').contentWindow;
		theFrame.setFolderID();
	}

	function selectFolder(id,name,path)
	{
		var theFrame = document.getElementById('collab_tree_frame').contentWindow;
		theFrame.selectFolder(id,name,path);
	}
	
    function postAddForm() {
		var theFrame = document.getElementById('collab_tree_frame').contentWindow;
		theFrame.postAddForm();
    }

    function postAddFolder() {
		var theFrame = document.getElementById('collab_tree_frame').contentWindow;
		theFrame.postAddFolder();
    }
	
    function postAddPart() {
		var theFrame = document.getElementById('collab_tree_frame').contentWindow;
		theFrame.postAddPart();
    }

    function postImportPart() {
		var theFrame = document.getElementById('collab_tree_frame').contentWindow;
		theFrame.postImportPart();
    }

    function postIncludePart() {
		var theFrame = document.getElementById('collab_tree_frame').contentWindow;
		theFrame.postIncludePart();
    }

	function postIncData() {
		var theFrame = document.getElementById('collab_tree_frame').contentWindow;
		theFrame.postIncData();		
	}
	
    function postAddFile() {
		var theFrame = document.getElementById('collab_tree_frame').contentWindow;
		selId = theFrame.selId;
		selName = theFrame.selName;
		selPath = theFrame.selPath;
		theFrame.postAddFile();
    }
	
    function postAddMultiFile() {
		var theFrame = document.getElementById('collab_tree_frame').contentWindow;
		theFrame.postAddMultiFile();
    }
	
    function doRenameFolder() {
		var theFrame = document.getElementById('collab_tree_frame').contentWindow;
		var name = document.hierform.newName.value;
		theFrame.doRenameFolder(name);
    }

    function doRenameItem() {
		var theFrame = document.getElementById('collab_data_frame').contentWindow;
		var name = document.hierform.newName.value;
		theFrame.doRenameItem(name);
    }
	
    function doCopyItem() {
		var theFrame = document.getElementById('collab_data_frame').contentWindow;
		var name = document.hierform.newName.value;
		theFrame.doCopy(name);
    }
	
    function doRemoveRelation() {
		var theFrame = document.getElementById('collab_data_frame').contentWindow;
		theFrame.doRemoveRelation();
    }
	
	function doDeleteData() {
		var theFrame = document.getElementById('collab_data_frame').contentWindow;
		theFrame.doDeleteData();
    }
	
	function doDeleteVer() {
		var theFrame = document.getElementById('collab_data_frame').contentWindow;
		theFrame.doDeleteVer();
    }
	
	function doRemovePart() {
		var theFrame = document.getElementById('collab_data_frame').contentWindow;
		theFrame.doRemovePart();
    }
	
	var selId = "";
	var selName = "";
	var selPath = "";