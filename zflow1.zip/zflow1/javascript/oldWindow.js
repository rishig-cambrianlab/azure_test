function viewWindow(link) {
        var now = new Date
        var nam = now.getTime()
		window.open(link, nam, "toolbar=no,status=yes,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=400,height=550")		
}

function editWindow(link) {
        var now = new Date
        var nam = now.getTime()
		window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=450,height=650")
}

function editPartWindow(link) {
        var now = new Date
        var nam = now.getTime()
		window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=450,height=250")
}

function createWindow(link) {
        var now = new Date
        var nam = now.getTime()        
		window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=400,height=550")
}

function createObjWindow(link) {
        var now = new Date
        var nam = now.getTime()        
		window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=400,height=550")
}

function queryWindow(link) {
        var now = new Date
        var nam = now.getTime()
        window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=400,height=650")
}

function navigateWindow(link) {
        var now = new Date
        var nam = now.getTime()
        //window.open(link, nam, "toolbar=no,status=yes,locationbar=no,scrollbars=yes,resizable=yes,top=25,left=50,width=900,height=650")		
		window.location.href=link;
}

function addRemUsrWindow(link) {
        var now = new Date
        var nam = now.getTime()
        window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=600,height= 500")
}

function uploadWindow(link) {
        var now = new Date
        var nam = now.getTime()
        window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=100,left=100,width=450,height=350")
}

function uploadFrmExtSysWindow(link) {
        var now = new Date
        var nam = now.getTime()
        window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=100,left=100,width=400,height=250")
}

function updateFrmExtSysWindow(link) {
        var now = new Date
        var nam = now.getTime()
        window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=100,left=150,width=400,height=250")
}

function chartWindow(link) {
        var now = new Date
        var nam = now.getTime()
        window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=750,height=550")
}

function reportsWindow(link) {
        var now = new Date
        var nam = now.getTime()
        window.open(link, nam, "toolbar=no,status=yes,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=700,height=550")
}

function releaseWindow(link) {
        var now = new Date
        var nam = now.getTime()
        window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=500,height=350")
}

function bomeditWindow(link) {
        var now = new Date
        var nam = now.getTime()
        window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=800,height=400")
}

function partdataWindow(link) {
        var now = new Date
        var nam = now.getTime()
        window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=800,height=350")
}

function permissionsWindow(link) {
        var now = new Date
        var nam = now.getTime()
        window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=900,height= 500")
}

function bomWindow(link) {
        var now = new Date
        var nam = now.getTime()
        window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=800,height= 600")
}

function qryselWindow(link) {
        var now = new Date
        var nam = now.getTime()
        window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=600,height= 600")
}

function toolLaunchWindow(link) {
        var now = new Date
        var nam = now.getTime()
        newwin = window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=200,height= 100")
		return newwin;
}

function popupWindow(link) {
        var now = new Date
        var nam = now.getTime()
        window.open(link, nam, "toolbar=no,statusbar=no,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=600,height= 675")
}

function addItemWindow(link) {
        var now = new Date
        var nam = now.getSeconds()
		window.open(link, nam, "toolbar=no,status=no,locationbar=no,scrollbars=yes,resizable=yes,top=300,left=300,width=300,height=150")		
}

function partsWindow(link) {
        var now = new Date
        var nam = now.getSeconds()
        window.open(link, nam, "toolbar=no,status=yes,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=700,height=650")
}
function searchWindow(link) {
        var now = new Date
        var nam = now.getSeconds()
        window.open(link, nam, "toolbar=no,status=yes,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=400,height=400");
}

function addEditFilesWindow(link) {
        var now = new Date 
        var nam = now.getTime()
        window.open(link, nam, "toolbar=no,status=yes,locationbar=no,scrollbars=yes,resizable=yes,top=50,left=300,width=760,height=450")
}

function processWindow(link) {
        var now = new Date
        var nam = now.getSeconds()
		window.open(link, nam, "toolbar=no,status=no,locationbar=no,scrollbars=yes,resizable=yes,top=25,left=25,width=1000,height=570")		
}
