    function isBlank(s) {
       var len = s.length ;
       var i ;
       for (i = 0 ; i < len ; i++) {
          if(s.charAt(i) != " ")
                return false ;
       }
       return true ;
    }

    function validateInput(fieldValue){
         if(isBlank(fieldValue)) {
              return false ; 
         }
         return true ;
    }
	
	/*	findNameElement: find the file/folder name element	*/					
	function findNameElement(thisform) {
		if ( thisform.elements[0].type == "text" )
		{	
			if ( ! validateName(thisform.elements[0].value))
			{
					thisform.elements[0].select();
					thisform.elements[0].focus();
					return false;	
			}
		}
		return true;
	}

	/*	validateName: check name validation	*/	
	function validateName(fieldValue, fieldName) {
		var tg1=/[\\\/:\*?"<>|]/;
		if ( tg1.test(fieldValue) )
		{
			if (fieldName == undefined || fieldName == null)
			{
				fieldName = '';
			}
			alert('Field ' + fieldName + ' cannot contain any of the following characters:\/:*?"<>|');
			return false;
		}
		return true;
	}

	/*	clearPassword: check if password and confirmpassword matches	*/	
	function clearPassword(thisform) {

		//search for element with password type
		for(var i=0;i<thisform.elements.length;i++){
			//If element type is password, check its value with that of the next element in the form.
			if(( thisform.elements[i].type == "password" )
			&& ( thisform.elements[i+1].type == "password")){
				//if values are not equal, display alert message and do not submit form.
				if(thisform.elements[i].value != thisform.elements[i+1].value){
					thisform.elements[i].value="";
					thisform.elements[i+1].value="";
					thisform.elements[i].focus();
					alert("Password confirmation doesn't match");
					return false;
			     }
			}
		}
		
		return true;
	}

	/*	processForm: submit form */	
	function processForm(thisform){
        elms = thisform.elements;
	    var i;
        for (i = 0; i < elms.length; i++)
        {
            if (elms[i].disabled)
            {
                elms[i].disabled = false;
            }
        }
		thisform.submit(); 
		return; 
	}