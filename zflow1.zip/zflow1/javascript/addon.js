	function open_dataitem(cls, fieldattr, fieldName, fieldNo, seltype, selcrit)
    {
		if (seltype == null) seltype = "";
		var value = "";
		var elems = document.forms[0].elements;
		var elemNo = 0;
        var elemNo2 = 0;
		var fieldID = fieldName + "ID";
		for (i=0;i < elems.length; i++)
		{
	    	if (fieldName == elems[i].name)
	    	{
		    	elemNo++;
		    	if (fieldNo == 0 || elemNo == fieldNo)
		    	{
					value = elems[i].value;
		    	}
			}
			else if (fieldID == elems[i].name)
			{
				elemNo2++;
				if (fieldNo == 0 || elemNo2 == fieldNo)
			    {	
					value = elems[i].value;
                }
			}
	    }

		if (value == '')
		{
			parent.showMessage("info","No item selected");
			return;
		}
		
		if (fieldattr.indexOf(":") != -1)
		{
			fieldattr = fieldattr.substring(0, fieldattr.indexOf(":"));
		}
		
		if (value.indexOf(",") == 0)
		{
			value = value.substring(1);
		}
		
		if (fieldattr == "UniqueID")
		{
		   var link = "../servlet/zapp";
		   var params = "command=view&cls=" +cls + "&scope=request&uniqueid=" + value;
		    
		   displayWindow(cls,"open",link,params);
		}
		else
		{
		   var link = "object.jsp";
		   var params = "view=true&cls=" +cls + "&uniqueattr=" + fieldattr + "&attrvalue=" + value;
		   displayWindow(cls,"open",link,params);
		}
	}
    
    function open_dataitem2(cls, fieldattr, value) 
    {
		if (value == '')
		{
			alert("No item selected");
			return;
		}
		if (fieldattr.indexOf(":") != -1)
		{
			fieldattr = fieldattr.substring(0, fieldattr.indexOf(":"));
		}
		if (fieldattr == "UniqueID")
		{
		   var link = "../servlet/zapp";
		   var params = "command=view&cls=" +cls + "&scope=request&uniqueid=" + value;
		    
		   displayWindow(cls,"open",link,params);
		}
		else
		{
		   var link = "object.jsp";
		   var params = "view=true&cls=" +cls + "&uniqueattr=" + fieldattr + "&attrvalue=" + value;
		   displayWindow(cls,"open",link,params);
		}
	}

    var taboncol = '#DBDBDB';
    var taboffcol = '#999999';
    var tabongif = "../images/subtab_on.gif";
    var taboffgif = "../images/subtab_off.gif";
	
    function showline(divid, line, total)
    {
        var i;
		var set_img_file, cur_img_file;
		
        for (i = 0; i < total; i++)
        {
            div = eval(divid + i);
            div.style.display = 'none';
            elem = eval(divid + "tabcol" + i);
            elem.bgColor = taboffcol;
            elem = eval(divid + "tabgif" + i);

			style = elem.currentStyle || window.getComputedStyle(elem, false),
			bi = style.backgroundImage.slice(4, -1).replace(/"/g, "");
			
			set_img_file = bi.replace(/^.*[\\\/]/, '');
			cur_img_file = tabongif.replace(/^.*[\\\/]/, '');
			
			if (set_img_file == cur_img_file)
			   elem.style.backgroundImage = "url('" + taboffgif + "')";
        }
        div = eval(divid + line);
        div.style.display = 'inline';
        elem = eval(divid + "tabcol" + line);
        elem.bgColor = taboncol;
        elem = eval(divid + "tabgif" + line);

		style = elem.currentStyle || window.getComputedStyle(elem, false),
		bi = style.backgroundImage.slice(4, -1).replace(/"/g, "");

		set_img_file = bi.replace(/^.*[\\\/]/, '');
		cur_img_file = taboffgif.replace(/^.*[\\\/]/, '');
		
		if (set_img_file == cur_img_file)
			elem.style.backgroundImage = "url('" + tabongif + "')" ;
		
		try 
		{
			elem = eval(divid + "tabcol" + "all");
			elem.bgColor = taboffcol;
			
			elem = eval(divid + "tabgif" + "all");
			
			style = elem.currentStyle || window.getComputedStyle(elem, false),
			bi = style.backgroundImage.slice(4, -1).replace(/"/g, "");

			set_img_file = bi.replace(/^.*[\\\/]/, '');
			cur_img_file = tabongif.replace(/^.*[\\\/]/, '');
		
			if (set_img_file == cur_img_file)
				elem.style.backgroundImage = "url('" + taboffgif + "')";
		}
		catch (x) {}
    }    
    
    function showall(divid, total)
    {
        var i;
		var set_img_file,cur_img_file;
        for (i = 0; i < total; i++)
        {
            div = eval(divid + i);
            div.style.display = 'inline';
            elem = eval(divid + "tabcol" + i);
            elem.bgColor = taboffcol;
            elem = eval(divid + "tabgif" + i);
			
			elem.style.backgroundImage = "url('" + taboffgif + "')" ;
        }
		
        elem = eval(divid + "tabcol" + "all");
        elem.bgColor = taboncol;
		
		elem = eval(divid + "tabgif" + "all");		
		elem.style.backgroundImage = "url('" + tabongif + "')" ;	
    }
    
    function showone(divid)
    {
        for(i=0;; i++)
        {
            try
	        {
	           div1 = eval(divid + i);
	            if (div1 != undefined)
	            {
	                if (i == 0)
	                    div1.style.display = 'inline';
	                else
	                    div1.style.display = 'none';
	            }
	            else
	                return
	        }
            catch (err)
            {
                return;
            }
        }
    }
	
	function isTablet()
	{
		var userAgent = navigator.userAgent.toLowerCase();
		var isTablet = /(ipad|tablet|(android(?!.*mobile))|(windows(?!.*phone)(.*touch))|kindle|playbook|silk|(puffin(?!.*(IP|AP|WP))))/.test(userAgent);
		return isTablet;
	}

	function createRequestObject() {
		var ro;
		var browser = navigator.appName;
		if(browser == "Microsoft Internet Explorer"){
			ro = new ActiveXObject("Microsoft.XMLHTTP");
		}else{
			ro = new XMLHttpRequest();
		}
		return ro;
	}
	
	function getContent(link, upd_div)
	{
		var http = createRequestObject();
		var jsp = link;
		http.open('get', jsp + '&uniqueParameter=' + (new Date()));
		http.onreadystatechange = function() {showContent(http, upd_div);};
		http.send(null);
	}

	function postContent(link, params, upd_div)
	{
		var http = createRequestObject();
		var jsp = link;
		http.open('post', jsp, false);
		http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');		
		http.onreadystatechange = function() {showContent(http, upd_div);};
		http.send(params);
	}

	function postContent_multipart(link, params, upd_div)
	{
		var http = createRequestObject();
		var jsp = link;
		http.open('post', jsp, true);
		http.setRequestHeader('Content-type', 'multipart/form-data');		
		http.onreadystatechange = function() {showContent(http, upd_div);};
		http.send(params);
	}
	
	function showContent(http, upd_div)
	{
		var contentdiv = document.getElementById(upd_div);

		if(http.readyState == 4 && http.status == 200)
		{
			var datacontent = http.responseText;			
			contentdiv.innerHTML = datacontent;
		}
	}
	
	function convertFormToParams(theForm)
	{
		var kvpairs = [];
		for ( var i = 0; i < theForm.elements.length; i++ ) {
			var e = theForm.elements[i];
			if (e.type == 'checkbox') {
				if (e.checked == true) {
					kvpairs.push(encodeURIComponent(e.name) + "=" + encodeURIComponent(e.value));
				}
			}
			else
			{
				kvpairs.push(encodeURIComponent(e.name) + "=" + encodeURIComponent(e.value));	
			}			
		}
		var queryString = kvpairs.join("&");
		return queryString;	
	}

	function getFrame( frameRef ) {
		return frameRef.contentWindow
			? frameRef.contentWindow.document
			: frameRef.contentDocument
	}
	
	function post_to_url(path, params, method) {
		method = method || 'POST';

		var form = document.createElement('form');

		// Move the submit function to another variable
		// so that it doesn't get overwritten.
		form._submit_function_ = form.submit;

		form.setAttribute('method', method);
		form.setAttribute('action', path);
		form.setAttribute('target', '_blank');

		for(var key in params) {
			var hiddenField = document.createElement('input');
			hiddenField.setAttribute('type', 'hidden');
			hiddenField.setAttribute('name', key);
			hiddenField.setAttribute('value', params[key]);

			form.appendChild(hiddenField);
		}

		document.body.appendChild(form);
		form._submit_function_(); // Call the renamed function.
	}
	
    function isNumberKey(evt)
    {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

        return true;
    }
	
    function execFunc(panel_id, jFunc, params)
    {
        eval(jFunc + "('" + params + "')");
	}
	
	function getMatchedVals(attr, checkcls, checkattr)
	{
		var val = eval("document.objform." + attr + ".value");
		
		if(val == "")
			return;
		
		var link = "get_value_matches.jsp?cls=" + attr + "&attrval=" + val + "&checkcls=" + checkcls + "&checkattr=" + checkattr ;
		
		var http = createRequestObject();
		var jsp = link;
		http.open('get', jsp + '&uniqueParameter=' + (new Date()));
		http.onreadystatechange = function() {showMatches(http);};
		http.send(null);		
	}
	
	function showMatches(http)
	{
		var contentdiv = document.getElementById("match_vals");

		if(http.readyState == 4 && http.status == 200)
		{
			var datacontent = http.responseText;
			if(datacontent.length > 64)
			{
				contentdiv.innerHTML = datacontent;
				document.getElementById("showmatches").style.display = 'inline';
			}
		}
		else
		{
			contentdiv.innerHTML = "<h6...</h6>";
		}	
	}
	
	String.prototype.trimLeft = function(charlist) {
	  if (charlist === undefined)
		charlist = "\s";

	  return this.replace(new RegExp("^[" + charlist + "]+"), "");
	};
	
	String.prototype.trimLeft = function(charlist) {
	  if (charlist === undefined)
		charlist = "\s";

	  return this.replace(new RegExp("^[" + charlist + "]+"), "");
	};
	
	String.prototype.trimRight = function(charlist) {
	  if (charlist === undefined)
		charlist = "\s";

	  return this.replace(new RegExp("[" + charlist + "]+$"), "");
	};
	
	String.prototype.trim = function(charlist) {
	  return this.trimLeft(charlist).trimRight(charlist);
	};
	
	var parseQueryString = function( queryString ) {
		var params = {}, queries, temp, i, l;

		// Split into key/value pairs
		queries = queryString.split("&");

		// Convert the array of strings into an object
		for ( i = 0, l = queries.length; i < l; i++ ) {
			temp = queries[i].split('=');
			params[temp[0]] = temp[1];
		}

		return params;
	};
	
	function selectOpportunity(obj)
	{
		showBusy(true);
		var link = "get_opportunities.jsp" ;
		var params = "colluid=" + collabid + "&scope=db&account=" + obj.value;
		
		var http = createRequestObject();
		var jsp = link + "?" + params ;
		http.open('get', jsp + '&uniqueParameter=' + (new Date()));
		http.onreadystatechange = function() {showOpportunities(http, link, params);};
		http.send(null);		
	};
	
	function showOpportunities(http, link, params)
	{
		if(http.readyState == 4 && http.status == 200)
		{
			var datacontent = http.responseText;
			if(datacontent.length > 64)
			{
				displayWindow("SalesOpportunity","list",link, params);
				showBusy(false);
			}
		}
		else
		{
			;
		}	
	};

	function getBankInfo(obj)
	{
		if(obj.value == "")
		{
			showMessage("info","Please enter the IBAN number ");
			return;
		}
		showBusy(true);
		var link = "get_bankinfo.jsp?colluid=" + collabid + "&iban=" + obj.value;
		
		$.getJSON({
			url: link
		}).done(function (result, status, xhr) {
			console.log(xhr,status,result);
			var message = xhr.responseJSON.success;
			console.log(message);			
			console.log(result);
			
			var robj = result;
			// we set the values of the variables
			
			if(robj["Valid"] == "no")
			{
				showMessage("error", "Invalid IBAN number " + "<br>" + robj["Message"]);
				obj.style.backgroundColor='orange';
				var elem1 = document.getElementById('BankName_0');
				elem1.value = "";
				var elem2 = document.getElementById('BankCode_0');
				elem2.value = "";
				var elem2 = document.getElementById('BIC_0');
				elem2.value = "";	
				obj.focus();
			}
			else
			{
				setResults(0, robj);
			}

			showBusy(false);
			
		}).fail(function (xhr, status, error) {
			console.log(xhr,status,error);
			console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
		});
	}

	function setResults(index, robj)
	{
		var elem1 = document.getElementById('BankName_' + index);
		elem1.value = robj["BankName"];
		var elem2 = document.getElementById('BankCode_' + index);
		elem2.value = robj["BankCode"];
		var elem2 = document.getElementById('BIC_' + index);
		elem2.value = robj["BICCode"];			
	}		
	
	function selectAsset(obj)
	{
		showBusy(true);
		var link = "get_assets.jsp" ;
		var params = "colluid=<%=colluid%>&scope=db&account=" + obj.value;
		var http = createRequestObject();
		var jsp = link + "?" + params ;
		http.open('get', jsp + '&uniqueParameter=' + (new Date()));
		http.onreadystatechange = function() {showAssets(http, link, params);};
		http.send(null);		
	}
	
	function showAssets(http, link, params)
	{
		if(http.readyState == 4 && http.status == 200)
		{
			var datacontent = http.responseText;
			if(datacontent.length > 64)
			{
				displayWindow("Account","list",link, params);
				showBusy(false);
			}
		}
		else
		{
			;
		}	
	}

	function showBusinessMatches(obj,cls,attr)
	{
		if(obj.value == "")
			return;

		showBusy(true);
		var link = "getBusinessMatches.jsp?colluid=" + collabid + "&scope=db&cls=" + cls + "&attr=" + attr + "&attrval=" + obj.value;
		
		$.getJSON({
			url: link
		}).done(function (result, status, xhr) {
			console.log(xhr,status,result);
			var message = xhr.responseJSON.success;
			console.log(message);			
			console.log(result);
			
			var robj = result;
			// we set the values of the variables
			//alert(result);
			showBusinessMatchResults(obj,robj["matches"]);

			showBusy(false);
			
		}).fail(function (xhr, status, error) {
			console.log(xhr,status,error);
			console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
		});
		
	}
	
	function showBusinessMatchResults(obj, matches)
	{
		var mdiv = document.getElementById("showbusinessmatches");
		var elem2 = document.getElementById("bmatch_vals");
		elem2.innerHTML = matches;
		mdiv.style.display = 'inline';
	}
	
	
	function showMatches(obj,cls,attr)
	{
		if(obj.value == "")
			return;

		showBusy(true);
		var link = "getMatches.jsp?colluid=" + collabid + "&scope=db&cls=" + cls + "&attr=" + attr + "&attrval=" + obj.value;
		
		$.getJSON({
			url: link
		}).done(function (result, status, xhr) {
			console.log(xhr,status,result);
			var message = xhr.responseJSON.success;
			console.log(message);			
			console.log(result);
			
			var robj = result;
			// we set the values of the variables
			//alert(result);
			showMatchResults(obj,robj["matches"]);

			showBusy(false);
			
		}).fail(function (xhr, status, error) {
			console.log(xhr,status,error);
			console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
		});
		
	}
	
	function showMatchResults(obj, matches)
	{
		var mdiv = document.getElementById("showmatches");
		var elem2 = document.getElementById("match_vals");
		elem2.innerHTML = matches;
		mdiv.style.display = 'inline';
	}

	function isItemStatusValid(obj, cls)
	{
		var val = obj.value;
		if(val.length == 0) return;
		var err_message = "Error: '" + val + "' is Pending status";
		$.getJSON({
			url: "validateData.jsp?Cls=" + cls + "&attr=PartNo&val=" + val + "&attr2=RevisionStatus&val2=Pending&attr3=Superceded&val3=-"
		}).done(function (result, status, xhr) {
			//console.log(xhr,status,result);
			//var message = xhr.responseJSON.success;
			//console.log(message);
			var robj = result;
			document.objform.unique.value = "false";
			obj.style.backgroundColor='white';
			for (var i = 0, len = robj.length; i < len; i++) {
				if (robj[i].match == "true") {
					document.objform.unique.value = "true";
					obj.style.backgroundColor='orange';
					showMessage("error", err_message);
					obj.focus();
				}
			}
		}).fail(function (xhr, status, error) {
			console.log(xhr,status,error);
			console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
		});
	}
	