//Javascript coding for Input validation---

var whitespace = " \t\n\r"; 

function stripInitialWhitespace (s)

{   var i = 0;
    while ((i < s.length) && charInString (s.charAt(i), whitespace))
       i++;
    
    return s.substring (i, s.length);
}

function stripFinalWhitespace (s)

{   var i = s.length;
    while ((i < s.length) && charInString (s.charAt(i), whitespace))
       i--;
    return s.substring (0, i);
}

function charInString (c, s)
{   for (i = 0; i < s.length; i++)
    {   if (s.charAt(i) == c) return true;
    }
    return false
}
	 
function _CF_onError(form_object, input_object, object_value, error_message)
    {
	alert(error_message);
       	return false;	
    }



function _CF_hasValue(obj, obj_type) 
{
    if (obj_type == "TEXT" || obj_type == "PASSWORD")
	{
	    var string = stripInitialWhitespace(obj.value);
	    if (string == "")
    		return false;
    	else
		{
		    obj.value = string; 
      		return true
		}
    }
    else if (obj_type == "SELECT")
	{
        for (i=1; i < obj.length; i++)
	    	{
		if (obj.options[i].selected)
			return true;
			}

       	return false;	
	}
    else if (obj_type == "SINGLE_VALUE_RADIO" || obj_type == "SINGLE_VALUE_CHECKBOX")
	{

		if (obj.checked)
			return true;
		else
       		return false;	
	}
    else if (obj_type == "RADIO" || obj_type == "CHECKBOX")
	{

        for (i=0; i < obj.length; i++)
	    	{
		if (obj[i].checked)
			return true;
			}

       	return false;	
	}
}


//Returns true if value is a date format or is NULL
//otherwise returns false
function _CF_checkdate(object_value)
    {
	if (object_value.length == 0)
        return true;
    //Returns true if value is a date in the mm/dd/yyyy format
	isplit = object_value.indexOf("/");

	if (isplit == -1 || isplit == object_value.length)
		return false;

    sMonth = object_value.substring(0, isplit);
	isplit = object_value.indexOf("/", isplit + 1);

	if (isplit == -1 || (isplit + 1 ) == object_value.length)
		return false;

    sDay = object_value.substring((sMonth.length + 1), isplit);

	sYear = object_value.substring(isplit + 1);

	if (!_CF_checkinteger(sMonth)) //check month
		return false;
	else
	if (!_CF_checkrange(sMonth, 1, 12)) //check month
		return false;
	else
	if (!_CF_checkinteger(sYear)) //check year
		return false;
	else
	if (!_CF_checkrange(sYear, 1601, 9999)) //check year
		return false;
	else
	if (!_CF_checkinteger(sDay)) //check day
		return false;
	else
	if (!_CF_checkday(sYear, sMonth, sDay)) // check day
		return false;
	else
		return true;
    }



function _CF_checkday(checkYear, checkMonth, checkDay)
    {

	maxDay = 31;

	if (checkMonth == 4 || checkMonth == 6 ||
			checkMonth == 9 || checkMonth == 11)
		maxDay = 30;
	else
	if (checkMonth == 2)
	{
		if (checkYear % 4 > 0)
			maxDay =28;
		else
		if (checkYear % 100 == 0 && checkYear % 400 > 0)
			maxDay = 28;
		else
			maxDay = 29;
	}

	return _CF_checkrange(checkDay, 1, maxDay); //check day
    }

	
function _CF_checkemail(object_value)
{
      if (object_value.length == 0)
        return true;
      var i = 1;
	  var length = object_value.length;
	  // look for @
      while ( (i < length) && (object_value.charAt(i) != "@"))
	  {   i++  }
	  if ( (i >= length) || (object_value.charAt(i) != "@"))
	  {   return false   }
	  else
	  {   i += 2;  }
	  // look for .
	  while ((i < length) && (object_value.charAt(i) != "."))
      {   i++  }
      // there must be at least one character after the .
      if ((i >= length - 1) || (object_value.charAt(i) != ".")) 
	  {   return false   }
      else 
	  {   return true;  
	   }
}

function _CF_checkinteger(object_value)
    {
    //Returns true if value is a number or is NULL
    //otherwise returns false	

    if (object_value.length == 0)
        return true;

    //Returns true if value is an integer defined as
    //   having an optional leading + or -.
    //   otherwise containing only the characters 0-9.
	var decimal_format = ".";
	var check_char;

    //The first character can be + -  blank or a digit.
	check_char = object_value.indexOf(decimal_format)
    //Was it a decimal?
    if (check_char < 1)
	return _CF_checknumber(object_value);
    else
	return false;
    }



function _CF_numberrange(object_value, min_value, max_value)
    {
    // check minimum
    if (min_value != null)
	{
        if (object_value < min_value)
		return false;
	}

    // check maximum
    if (max_value != null)
	{
	if (object_value > max_value)
		return false;
	}
	
    //All tests passed, so...
    return true;
    }



function _CF_checknumber(object_value)
    {
    //Returns true if value is a number or is NULL
    //otherwise returns false	

    if (object_value.length == 0)
        return true;

    //Returns true if value is a number defined as
    //   having an optional leading + or -.
    //   having at most 1 decimal point.
    //   otherwise containing only the characters 0-9.
	var start_format = " .+-0123456789";
	var number_format = " .0123456789";
	var check_char;
	var decimal = false;
	var trailing_blank = false;
	var digits = false;

    //The first character can be + - .  blank or a digit.
	check_char = start_format.indexOf(object_value.charAt(0))
    //Was it a decimal?
	if (check_char == 1)
	    decimal = true;
	else if (check_char < 1)
		return false;
        
	//Remaining characters can be only . or a digit, but only one decimal.
	for (var i = 1; i < object_value.length; i++)
	{
		check_char = number_format.indexOf(object_value.charAt(i))
		if (check_char < 0)
			return false;
		else if (check_char == 1)
		{
			if (decimal)		// Second decimal.
				return false;
			else
				decimal = true;
		}
		else if (check_char == 0)
		{
			if (decimal || digits)	
				trailing_blank = true;
        // ignore leading blanks

		}
	        else if (trailing_blank)
			return false;
		else
			digits = true;
	}	
    //All tests passed, so...
    return true
    }



function _CF_checkrange(object_value, min_value, max_value)
    {
    //if value is in range then return true else return false

    if (object_value.length == 0)
        return true;


    if (!_CF_checknumber(object_value))
	{
	return false;
	}
    else
	{
	return (_CF_numberrange((eval(object_value)), min_value, max_value));
	}
	
    //All tests passed, so...
    return true;
    }

function _CF_checkday_event(checkYear, checkMonth, checkDay)
    {
     
	maxDay = 31;

	if (checkMonth == 4 || checkMonth == 6 ||
			checkMonth == 9 || checkMonth == 11)
		maxDay = 30;
	else
	if (checkMonth == 2)
	{
		if (checkYear % 4 > 0)
			maxDay =28;
		else
		if (checkYear % 100 == 0 && checkYear % 400 > 0)
			maxDay = 28;
		else
			maxDay = 29;
	}

	return _CF_checkrange_event(checkDay, 1, maxDay); //check day
    }

function _CF_checkrange_event(object_value, min_value, max_value)
    {
    //if value is in range then return true else return false

    if (object_value.length == 0)
        return true; 

	return (_CF_numberrange((eval(object_value)), min_value, max_value));
	
    //All tests passed, so...
    return true;
    }

function _CF_checkphone(object_value)
    {
    if (object_value.length == 0)
        return true;
		
    if (object_value.length != 12)
        return false;

	// check if first 3 characters represent a valid area code
    if (!_CF_checknumber(object_value.substring(0,3)))
		return false;
    else
	if (!_CF_numberrange((eval(object_value.substring(0,3))), 100, 1000))
		return false;

	// check if area code/exchange separator is either a'-' or ' '
	if (object_value.charAt(3) != "-" && object_value.charAt(3) != " ")
        return false

	// check if  characters 5 - 7 represent a valid exchange
    if (!_CF_checknumber(object_value.substring(4,7)))
		return false;
    else
	if (!_CF_numberrange((eval(object_value.substring(4,7))), 100, 1000))
		return false;
	
	// check if exchange/number separator is either a'-' or ' '
	if (object_value.charAt(7) != "-" && object_value.charAt(7) != " ")
        return false;

	// make sure last for digits are a valid integer
	if (object_value.charAt(8) == "-" || object_value.charAt(8) == "+")
        return false;
	else
	{
		return (_CF_checkinteger(object_value.substring(8,12)));
	}
    
 }
 
 function _CF_checkphone1(object_value)
       {
	      if (object_value.length == 0)
        return true;
		
    if (object_value.length != 13)
        return false;

	// check if first 3 characters represent a valid area code

    if (!_CF_checknumber(object_value.substring(1,4)))
		return false;
    else
	
	if (!_CF_numberrange((eval(object_value.substring(1,4))), 100, 1000))
		return false;

	// check if area code/exchange separator is either a')'
	
	if (object_value.charAt(4) != ")" && object_value.charAt(4) != " ")
        return false

	// check if  characters 5 - 8 represent a valid exchange

    if (!_CF_checknumber(object_value.substring(5,8)))
		return false;
    else
	
	if (!_CF_numberrange((eval(object_value.substring(5,8))), 100, 1000))
		return false;
	
	// check if exchange/number separator is either a'-' or ' '
	
	if (object_value.charAt(8) != "-" && object_value.charAt(8) != " ")
        return false;

	// make sure last four digits are a valid integer

	if (object_value.charAt(9) == "-" || object_value.charAt(9) == "+")
        return false;
	else
	{
		return (_CF_checkinteger(object_value.substring(9,13)));
	}
    
 }
 
function _CF_checkzip(object_value)
    {
    if (object_value.length == 0)
        return true;
                
    if (object_value.length != 5 && object_value.length != 10)
        return false;

        // make sure first 5 digits are a valid integer
        if (object_value.charAt(0) == "-" || object_value.charAt(0) == "+")
        return false;

        if (!_CF_checkinteger(object_value.substring(0,5)))
                return false;

        if (object_value.length == 5)
                return true;
        
        // make sure

        // check if separator is either a'-' or ' '
        if (object_value.charAt(5) != "-" && object_value.charAt(5) != " ")
        return false;

        // check if last 4 digits are a valid integer
        if (object_value.charAt(6) == "-" || object_value.charAt(6) == "+")
        return false;

        return (_CF_checkinteger(object_value.substring(6,10)));
    }
	
// validation for entered date against current date........	
	
	function _CF_checkdate_currentdate(object_value)
	{
	   var theDate = new Date();
	   var enteredDate = new Date(object_value);
	 
// if entered year is less than current year......	 
	 	 
		 if (enteredDate.getFullYear() < theDate.getFullYear())
	      {	
	         alert("Date expired! Please check the entered date")    	   
		     return false;
	      }
		 
// if year are the same but  entered month is less	 than current month...
		
		 if ((enteredDate.getFullYear() == theDate.getFullYear())&&
	            (enteredDate.getMonth() <  theDate.getMonth()))
	       {
	    	 alert("Date expired! Please check the entered date")
			 return false;
    	   }
		
		
//	 year and month being same, if the entered date is less than current date.... 	
		if ((enteredDate.getFullYear() == theDate.getFullYear())&&
	   (enteredDate.getMonth() == theDate.getMonth())&&
	    (enteredDate.getDate() < theDate.getDate()))
	    {
	    alert("Date expired! Please check the entered date")
		   return false;
	    }
		
		
//If  entered(year ,month and date) are same as current ....			
		
	 if ((enteredDate.getFullYear() == theDate.getFullYear())&&
	   (enteredDate.getMonth() ==  theDate.getMonth())&&
	    (enteredDate.getDate() == theDate.getDate()))
	   {
	      
		  alert("Date expired! Please check the entered date")
		  return false;
	    }
		
		return true;
		
    }
	
//  -->
// convert data to currency format, num is the value of the data you need to format
function formatCurrency(num) 
{
	num = num.toString().replace(/\$|\,/g,'');
	if(isNaN(num))
		num = "0";
	sign = (num == (num = Math.abs(num)));
	num = Math.floor(num*100+0.50000000001);
	cents = num%100;
	num = Math.floor(num/100).toString();
	if(cents<10)
	cents = "0" + cents;
	for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
	num = num.substring(0,num.length-(4*i+3))+','+
	num.substring(num.length-(4*i+3));
	return (((sign)?'':'-') + '$' + num + '.' + cents);
}

function getformatCurrencyValue(num) 
{
	num = num.toString().replace(/\$|\,/g,'');
	if(isNaN(num))
		num = "0";
	sign = (num == (num = Math.abs(num)));
	num = Math.floor(num*100+0.50000000001);
	cents = num%100;
	num = Math.floor(num/100).toString();
	if(cents<10)
	cents = "0" + cents;
	for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
	num = num.substring(0,num.length-(4*i+3))+','+
	num.substring(num.length-(4*i+3));
	return (((sign)?'':'-') + '' + num + '.' + cents);
}

function isNumeric(fieldname,fieldObj)
{
	var fieldVal = removeCommas(fieldObj.value);
	if ( fieldVal == "" ) fieldObj.value = 0.00;
	if ( fieldVal != "" && ! _CF_checknumber(fieldVal) )
	{
		fieldObj.select();
		fieldObj.focus();
		alert("Please enter a numeric value for "+fieldname);	
		fieldObj.value = fieldObj.defaultValue;		
		return false;
	}
	return true;
}

String.prototype.trim = function() {

// skip leading and trailing whitespace
// and return everything in between
  return this.replace(/^\s*(\b.*\b|)\s*$/, "$1");

}
