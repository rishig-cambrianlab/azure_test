 	var commentsdiv = "_comments_div";
	var commentsform = "_commentform";

	function showCommentDialog(link, div_id) {	
		getContent(link, div_id);
		dialogShow(commentsdiv);
	}

	var lastFocus;
	
	function dialogShow (div_id) {
		var dialog = document.getElementById(div_id);
		dialog.style.display='inline';
		dialog.setAttribute('tabindex', '0');		

		lastFocus = document.activeElement;
		dialog.focus();
	}

	function dialogClose (div_id) {
		var dialog = document.getElementById(div_id);
		dialog.style.display='none';
		lastFocus.focus(); // place focus on the saved element
	}	

    function closeComments() {
		dialogClose(commentsdiv);
    }
	
	