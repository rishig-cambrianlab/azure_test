  function ToRight(left,right){
    countL=0;//total of unselected item on the left side
    countR=0;//total of selected item on the right side
    flag=0;//whether the item already on the right side(selected)
   
   lengthS=left.length;
   //record the numbers of the non-empty item on the right side
   for(n=1;n<right.length;n++){
    if(right.options[n] && !right.options[n].text == "")
      countR=countR+1;
    }
    
   var rightNewUser = "";
   for(n=1;n<lengthS;n++)
   {
		if(!left.options[n].selected)
		{
		  countL=countL+1;
		}
		else 
		{
			//check if the item is already selected (already on right side)
			 for(j=1;j<lengthS;j++)
				if(right.options[j] && right.options[j].text==left.options[n].text)
				{
				   countL=countL+1;
				   flag=1;
				   break;
				 } 
			//if item is new selected
			if(flag==0)
			{
//				alert("n="+n+"countL="+countL+"countR="+countR+" right length = " + right.length+"left="+left.length);
				right.options[n-countL+countR].text=left.options[n].text;
				right.options[n-countL+countR].value=left.options[n].value;
				rightNewUser = rightNewUser + "," + left.options[n].value;
			}
			if(flag==1)//reset flag
			  flag=0;    
		 }//end else
    } //end for 
   //reset left 
   for(n=0;n<lengthS;n++)
   {
     left.options[n].selected=false;
   }
 //  alert(rightNewUser);
//   document.left.order.value = rightNewUser;
  }


   
  function ToLeft(left,right){
	   lengthS=right.length;
	   var count1=0;
	   for(i=lengthS-1;i>0;i--){
			if(right.options[i].selected)
            {
			   for (j = i+1 ; j < lengthS; j++)
			   {
			    right.options[j-1].text=right.options[j].text;
			    right.options[j-1].value=right.options[j].value;
			   }
			    right.options[j-1].text="";
			    right.options[j-1].value="";
			}
	   } 
	   for(i=0;i<lengthS;i++){
		  right.options[i].selected=false;
	   }
 }

 function Reset(){
   lengthS=document.left.leftS.length;
   for(i=1;i<lengthS;i++){
     document.right.rightS.options[i].text="";  
   }
   document.right.rightS.options[0].text="-------------------------------";   

   //Lets create and array of orig list
   var userlist = new makearray(20);

   var origuserlist = document.theForm.prevlist.value;
   if(origuserlist.length > 0)
   {
		var origcount = 0;
		var reststr = origuserlist;
		var userid = "";
		while(true)
		{
			if (reststr.indexOf(",") < 0 )
			{
				userlist[origcount] = reststr;
				origcount++;
				break;
			}
			userid = reststr.substring(0,reststr.indexOf(","));
			if (userid.length > 0)
			{
				userlist[origcount] = userid;
				origcount++;
			}
			reststr = reststr.substring(reststr.indexOf(",") + 1, reststr.length);
		}
   }  

   for(i=0;i<lengthS;i++){
    document.right.rightS.options[i].selected=false;
    document.left.leftS.options[i].selected=false;
   }

   for(i=1;i<=origcount;i++){
	  for(j=1;j<lengthS;j++) {
	    if(document.left.leftS.options[j].value == userlist[i-1]){
		  document.right.rightS.options[i].text=document.left.leftS.options[j].text;
		  break;
		}
	  }
   }
 }
 
 function SortIt(){
  lengthS=document.left.leftS.length;
  dataLengthR=0;// selected data length on right side
  // record the data length on the right side
  for(i=1;i<lengthS;i++)
   if(document.right.rightS.options[i].text==""){
     dataLengthR=i-1;
     break;
    }
  //create a temperate array
  rightData = new Array(dataLengthR-1);
  
  for(i=0;i<dataLengthR;i++)
     rightData[i]=document.right.rightS.options[i+1].text;
   
 //sort data on right side
   rightData.sort();
   
  window.status=rightData.join();
   
 //display sorted data on right side
  for(i=0;i<dataLengthR;i++)
    document.right.rightS.options[i+1].text=rightData[i]; 
}

function makearray(num)
{
	this.length = num
	for (var i; i <= num ; i++) {
		this[i] = 0
	}
	return this
}

function validateSet(left,right)
{
   var userStr = "";
   lengthS=right.length;

   //Lets create and array of orig list
   var userlist = new makearray(20);
 
   var origuserlist = document.theForm.prevlist.value;
   if(origuserlist.length > 0 || origuserlist.length == 0 || origuserlist=="" || origuserlist==" ")
   {
		var origcount = 0;
		var reststr = origuserlist;
		var userid = "";
		while(true)
		{
			if (reststr.indexOf(",") < 0 )
			{
				userlist[origcount] = reststr;
				origcount++;
				break;
			}

			userid = reststr.substring(0,reststr.indexOf(","));

			if (userid.length > 0)
			{
				userlist[origcount] = userid;
				origcount++;
			}

			reststr = reststr.substring(reststr.indexOf(",") + 1, reststr.length);
		}
   }  

   //Lets create and array of current list
   var curlist = new makearray(lengthS);

   curcount = 0;
   var n = 0;
   //record the numbers of the non-empty item on the right side
   for(n=1; n<lengthS; n++){
		if(right.options[n] && !right.options[n].text == "")
		{
			curlist[curcount] = right.options[n].value;
			curcount++;
		}
   }

   var found = 0;
   var addStr = "";
   var removeStr = "";
   var initial = 0;

   for (var i = 0; i < curcount; i++ )
   {
		found = 0;
		for (var j = 0; j < origcount ; j++)
		{
			if (userlist[j] == curlist[i])
			{
				found = 1;
				break;
			}
		}

		if (found == 0) {
			if (initial == 0){
				addStr = curlist[i];
				initial = 1;
			}
			else
				addStr = addStr + "," + curlist[i];
		}
   }

   initial = 0;
   for (var i = 0; i < origcount; i++ ) {
		found = 0;
		for (var j = 0; j < curcount ; j++) {
			if (userlist[i] == curlist[j]) {
				found = 1;
				break;
			}
		}

		if (found == 0){
			if (initial == 0){
				removeStr = userlist[i];
				initial = 1;
			}
			else
				removeStr = removeStr + "," + userlist[i];
		}
   }
   document.theForm.addUsers.value = addStr;
   document.theForm.removeUsers.value = removeStr;

   return true;
}



 function moveUp(obj)
 {
	count=obj.length;
	sCount=0;

	for(c=0;c<count;c++)
	{
		if(obj.options[c].selected)
		{
			sCount=sCount+1;
		}
	}

	for(i=1;i<count;i++)
	{
		if(obj.options[i].selected && i > 1 && obj.options[i].text != "")
		{
			temp=obj.options[i].text;
			tempv=obj.options[i].value;
			obj.options[i].text=obj.options[i-1].text;
			obj.options[i].value=obj.options[i-1].value;
			obj.options[i-1].text=temp;
			obj.options[i-1].value=tempv;
			obj.options[i].selected=false;
			obj.options[i-1].selected=true;
		}
	}
 }

  function moveDown(obj)
 {
	count=obj.length;
	for(i=1;i<count;i++)
	{
		if(obj.options[i].selected && obj.options[i+1].text != "" &&  obj.options[i].text != "")
		{
			temp=obj.options[i].text;
			tempv=obj.options[i].value;
			obj.options[i].text=obj.options[i+1].text;
			obj.options[i].value=obj.options[i+1].value;
			obj.options[i+1].text=temp;
			obj.options[i+1].value=tempv;
			obj.options[i].selected=false;
			obj.options[i+1].selected=true;
			break;
		}
	}
 }