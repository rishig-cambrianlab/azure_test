	function isPartInSAP(obj)
	{
		if(obj.value == "")
		{
			showMessage("info","Please enter the number ");
			return;
		};
		var val = obj.value;
		if(val.length == 0) return;
		var err_message = "Error: '" + val + "' exists in SAP";
		$.getJSON({
			url: "isMaterialInSAP.jsp?partno=" + val
		}).done(function (result, status, xhr) {
			//console.log(xhr,status,result);
			//var message = xhr.responseJSON.success;
			//console.log(message);
			var robj = result;
			document.objform.unique.value = "false";
			obj.style.backgroundColor='white';
			for (var i = 0, len = robj.length; i < len; i++) {
				if (robj[i].match == "true") {
					document.objform.unique.value = "true";
					obj.style.backgroundColor='orange';
					showMessage("error", err_message);
					obj.focus();
				}
				else
				{
					obj.style.backgroundColor='white';
				}
			}
		}).fail(function (xhr, status, error) {
			console.log(xhr,status,error);
			console.log("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText)
		});
	};