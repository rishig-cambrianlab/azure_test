// functions to change menu background color after click
var ie = document.all?1:0;
var ns4 = document.layers?1:0;

function focusMe(e){
	dL(e);
	hL(e);
}
function hL(E){
	if (ie)
	{
		while (E.tagName!="TD")	{
			E=E.parentElement;
		}
	} else {
		while (E.tagName!="TD")	{
			E=E.parentNode;
		}
	}
	E.className = "H";
}

function dL(E){	
	tdNodes=document.getElementsByTagName('TD');
	 for ( i=0; i<tdNodes.length;i++ )
	 {
		 if ( tdNodes[i].className == "H")
		 {
			 tdNodes[i].className = "D";
		 }
	 }
}