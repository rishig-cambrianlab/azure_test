	function setDataPanel(link)
	{
		var theFrame = document.getElementById('repository_data_frame');
		theFrame.src = link;
	}
	
	function setDataPanelVal(varname, varval)
	{
		var theFrame = document.getElementById('repository_data_frame').contentWindow;
		theFrame.varname = varval;
	}
	
	function selectTreeItem(id, name)
	{
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		theFrame.reselect(id,name);
	}

	function setIconPanel(panel_id,content)
	{
		getContent("actions_inline_horizontal.jsp?panel_id=" + panel_id + "&winName=" + window.name + content,"_repository_icon_panel");		
	}
	
	function execFunc(panel_id, jFunc, params)
	{
		var theFrame = document.getElementById(panel_id).contentWindow;
		theFrame.eval(jFunc + "(" + params + ")");	
	}
	
	function clearDataIconPanel()
	{
		document.getElementById("_repository_icon_panel").innerHTML='';
	}
	
	function getFolderID()
	{
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		return theFrame.getFolderID();
	}

    function postEditFolder() {
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		theFrame.postEditFolder();
    }

    function postRenameFolder() {
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		theFrame.postRenameFolder();
    }

    function postViewFolder() {
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		theFrame.postViewFolder();
    }

    function postAddFolder() {
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		theFrame.postAddFolder();
    }

    function postRemFolder() {
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		theFrame.postRemFolder();
    }

    function postFolderSecurity() {
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		theFrame.postFolderSecurity();
    }
	
    function postAddForm() {
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		theFrame.postAddForm();
    }

    function postAddPart() {
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		theFrame.postAddPart();
    }

    function postImportPart() {
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		theFrame.postImportPart();
    }

    function postIncludePart() {
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		theFrame.postIncludePart();
    }

    function postAddFile() {
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		theFrame.postAddFile();
    }
	
    function postAddMultiFile() {
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		theFrame.postAddMultiFile();
    }
	
    function doRenameFolder() {
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		var name = document.hierform.newName.value;
		theFrame.doRename(name);
    }

    function doDeleteFolder() {
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		theFrame.doDelete();
    }

    function reselectFolder() {
		var theFrame = document.getElementById('repository_tree_frame').contentWindow;
		theFrame.relectFolder();
    }
	
    function doRenameItem() {
		var theFrame = document.getElementById('repository_data_frame').contentWindow;
		var name = document.hierform.newName.value;
		theFrame.doRename(name);
    }
	
    function doCopyItem() {
		var theFrame = document.getElementById('repository_data_frame').contentWindow;
		var name = document.hierform.newName.value;
		theFrame.doCopy(name);
    }