
    function accessApplet(){

       var lan = document.loc.language ;
       var co = document.loc.country ;
       
       if (lan == "" || lan == null || co == undefined )
       {
       
          lan = "en"
          co = "US"
       }

       document.frmSubmit.language.value = lan ;
       document.frmSubmit.country.value = co ;
    }
