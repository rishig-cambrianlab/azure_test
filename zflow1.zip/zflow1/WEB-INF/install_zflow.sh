#!/bin/bash
#
# Script to install zflow
##
#1.	wget https://testdtive.zflow.io/zflow.tar.gz
#2.	Ask for db,dbuser,dbuserpassword,admin user email,admin user password, confirm password
#3.	check db,dbuser,dbuserpassword are valid
#4.	updata config with values from step 2
#5.	Start tomcat and run rest of the install
#6.	Ready for login at the correct URL http://IP:8080/zflow
#
echo ""
echo "		Installing ZFLOW ..." 
echo ""
TSERVICE=tomcat8
service $TSERVICE status >/dev/null
if [ $? -ne 0 ]
then
	TSERVICE=tomcat
	service $TSERVICE status >/dev/null
	if [ $? -ne 0 ]
	then
		read -r -p "Please enter tomcat service name: " TSERVICE
		service $TSERVICE status >/dev/null
		if [ $? -ne 0 ]
		then
			echo "tomcat8 service not found"
			exit 1
		fi
	fi
fi
CURDIR=$PWD
pidProx=$(pgrep -f tomcat);
if [ "$pidProx" != "" ]; then
	sudo service $TSERVICE stop
	sleep 1
fi
pidProx=$(pgrep -f tomcat);
if [ "$pidProx" != "" ]; then
	  echo "Please stop Tomcat Server, pid=$pidProx ........";
	  exit
fi

WEBAPPSDIR=/var/lib/tomcat8/webapps
if [ ! -e $WEBAPPSDIR ]; then
   echo "Webapps directory not found"
   otherwebdir=""
   read -r -p "Please enter tomcat webapps directory: " otherwebdir
   if [ -e $otherwebdir ]; then
	WEBAPPSDIR=$otherwebdir
   else
	echo "webapps directory not found: $otherwebdir"
	exit 1
   fi
fi

SITENAME=zflow
if [ -e $WEBAPPSDIR/$SITENAME ]; then
	read -r -p "zflow installation already exists. Remove existing installation? [y/N] " response
	if [[ $response =~ ^([yY][eE][sS]|[yY])$ ]]
	then
	    echo ""
	    echo "Deleting existing installation ..."
	    rm -rf $WEBAPPSDIR/$SITENAME
	    echo ""
	else
	    echo ""
	    echo "Installation cancelled"
	    echo ""
	    exit
	fi
fi
read -r -p "Please enter Database Name: " DBNAME
read -r -p "Please enter Database User: " DBUSER
read -r -s -p "Please enter Database User Password: " DBPASSWORD
echo ""
mysql -u$DBUSER -p$DBPASSWORD -e "use $DBNAME; show tables"
retVal=$?
if [ $retVal -ne 0 ]; then
    echo "Error accessing database"
    exit 1;
fi
read -r -p "Please enter ZFLOW Admin email address: " ADMINEMAIL
read -s -p "Please enter ZFLOW Admin password: " ADMINPWD
echo ""
read -s -p "Please enter ZFLOW Admin password again: " PSW2
echo ""
IFS="@"
set -- $ADMINEMAIL
parts="${#@}"
domain="$2"
if [ "$domain" == "" ]; then
    domain="xx"
fi
okdomain=`dig $domain | grep "ANSWER: 1"`
#if [[ expression && ( expression || expression ) ]] ; then
if [[ "$ADMINEMAIL" != "" && ( $parts -ne 2 || "$okdomain" == "" ) ]]; then
   echo "Error:Invalid email"
   exit 1
fi
if [ "$ADMINEMAIL" != "" ]; then
        if [ "$ADMINPWD" != "$PSW2" ] || [ ${#ADMINPWD} -lt 6 ]; then
                echo "Invalid passwords should be at least 6 characters"
		exit 1
        fi
fi
if hash wget 2>/dev/null; then
	wget https://testdrive.zflow.io/zflow.tar.gz
else
	echo ">>>>> Please install wget to download the ZFLOW software <<<<<"
fi
gunzip zflow.tar.gz
cd $WEBAPPSDIR
tar xf $CURDIR/zflow.tar
sudo chown -R tomcat zflow
sudo chgrp -R tomcat zflow
sed -i "s|3306/zflow|3306/$DBNAME|g" zflow/WEB-INF/classes/cfg/ZFlowConfig.properties
sed -i "s|DB_PASSWD=Encoded:BA56A79B4C39D2CC69DB23AB68DB308F|DB_PASSWD=$DBPASSWORD|g" zflow/WEB-INF/classes/cfg/ZFlowConfig.properties
sed -i "s|DB_USER=zdbuser|DB_USER=$DBUSER|g" zflow/WEB-INF/classes/cfg/ZFlowConfig.properties
if [ "otherwebdir" != "" ]; then
	sed -i "s|/var/lib/tomcat8/webapps|$otherwebdir|g" zflow/WEB-INF/web.xml
fi
cd $CURDIR
sudo service $TSERVICE start
echo "Waiting for tomcat to install app ...."
sleep 30
TOM=`netstat -tulpn | grep LISTEN | grep 8080`
if [ "$TOM" == "" ]; then
	echo "Still waiting for tomcat..."
	sleep 30
fi
TOM=`netstat -tulpn | grep LISTEN | grep 8080`
if [ "$TOM" == "" ]; then
	echo "tomcat still no ready, continuing ..."
fi
mysql -u$DBUSER -p$DBPASSWORD -e "INSERT INTO $DBNAME.Usr ( Creator, CreDate, CurDb, LastUpdate, UniqueID ,Password,Manager,Zip,EMail,Department,Role,ParentOrgID,PostNotify,LastName,Locale,FirstName,Active,PwdExpired,PreNotify,Class,PwdDate,OutOfOffice ) VALUES ('admin@zflow.com' , '2020-08-14 10:21:52' , 'root' ,'2020-08-14 10:21:52' , 'uid:5c1b0a6b:16ac1a84252:g7fff:zplm:8084' ,'$ADMINPWD',null,'','$ADMINEMAIL',null,'admin','uid:g2ce1cbd2:163e640bcc9:g7ff7:b2bm2:8084','+','Admin','en','Admin','+','-','+','Usr','2020-08-14 0:00:00','-')"
pidProx=$(pgrep -f tomcat);
if [ "$pidProx" == "" ]; then
	  echo "Please start Tomcat Server";
	  exit
else
	echo "Please navigate to http://`hostname`:8080/zflow and login as $ADMINEMAIL"
fi
