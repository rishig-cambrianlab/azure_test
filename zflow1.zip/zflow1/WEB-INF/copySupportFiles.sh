#!/bin/bash
#
# Script to copy files to support website
##
cd ~/source/zflow22
git pull
echo "Copying version.jsp ..."
sudo cp -p version.jsp /usr/share/tomcat8/webapps/ROOT/
echo "Copying zbase.jar ..."
sudo cp -p web/WEB-INF/lib/zbase.jar /usr/share/tomcat8/webapps/ROOT/
echo "Copying zcustom.jar ..."
sudo cp -p web/WEB-INF/lib/zcustom.jar /usr/share/tomcat8/webapps/ROOT/
echo "Copying zadapters.jar ..."
sudo cp -p web/WEB-INF/lib/zadapters.jar /usr/share/tomcat8/webapps/ROOT/
echo "Copying nui.zip ..."
sudo cp -p web/nui.zip /usr/share/tomcat8/webapps/ROOT/
echo "Copying forms.js ..."
sudo cp -p web/javascript/forms.js /usr/share/tomcat8/webapps/ROOT/
# Loop over file in jarlist.txt
filename="web/WEB-INF/jarlist.txt"
while read -r line || [[ -n "$line" ]]
do
	line=$(echo $line | sed -e 's/\r//g')
	echo "Copying $line ..."
	sudo cp -p web/WEB-INF/lib/$line /usr/share/tomcat8/webapps/ROOT/
done < "$filename"
sudo cp -p $filename /usr/share/tomcat8/webapps/ROOT/